import React, { useState, useRef } from 'react';
import {
  Download,
  Upload,
  Copy,
  Check,
  Users,
  Shield,
  Trash2,
  Plus,
  RefreshCw,
  AlertTriangle,
  History,
  FileCode,
  Smartphone,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { AppState, Profile, BackupSnapshot } from '../../types';
import {
  downloadTrackerJSON,
  exportTrackerBlob,
  validateAndNormalizeJSON,
  ValidationResult,
} from '../../utils/jsonHandler';
import { formatDateToLocal } from '../../utils/streak';
import { PWAInstallButton } from '../common/PWAInstallButton';

interface SettingsViewProps {
  appState: AppState;
  activeProfile: Profile;
  backups: BackupSnapshot[];
  onSelectProfile: (id: string) => void;
  onCreateProfile: (name: string, targetScore: number) => void;
  onUpdateProfile: (profileId: string, name: string, targetScore: number) => void;
  onDeleteProfile: (profileId: string) => void;
  onApplyImportedState: (newState: AppState) => void;
  onRestoreSnapshot: (snapshot: BackupSnapshot) => void;
  onResetAllData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  appState,
  activeProfile,
  backups,
  onSelectProfile,
  onCreateProfile,
  onUpdateProfile,
  onDeleteProfile,
  onApplyImportedState,
  onRestoreSnapshot,
  onResetAllData,
}) => {
  const [copiedSuccess, setCopiedSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Profile modals
  const [isNewProfileModalOpen, setIsNewProfileModalOpen] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [newTargetScore, setNewTargetScore] = useState(95);

  const [editProfileModal, setEditProfileModal] = useState<Profile | null>(null);
  const [editProfileName, setEditProfileName] = useState('');
  const [editTargetScore, setEditTargetScore] = useState(95);

  const [deleteProfileId, setDeleteProfileId] = useState<string | null>(null);

  // Import flow
  const [pasteJSONModalOpen, setPasteJSONModalOpen] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const [importPreview, setImportPreview] = useState<ValidationResult | null>(null);
  const [confirmReplaceModal, setConfirmReplaceModal] = useState<AppState | null>(null);

  // Reset confirmation
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  // Handle Export File Download
  const handleExportDownload = () => {
    downloadTrackerJSON(appState);
  };

  // Handle Copy JSON string
  const handleCopyJSON = async () => {
    try {
      const { jsonString } = exportTrackerBlob(appState);
      await navigator.clipboard.writeText(jsonString);
      setCopiedSuccess(true);
      setTimeout(() => setCopiedSuccess(false), 2500);
    } catch (e) {
      console.warn('Failed to copy to clipboard', e);
    }
  };

  // Handle File Input Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = validateAndNormalizeJSON(content);
      if (res.valid && res.normalizedState) {
        setImportPreview(res);
        setConfirmReplaceModal(res.normalizedState);
      } else {
        alert(res.error || 'Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
    // Reset file input
    e.target.value = '';
  };

  // Handle Paste JSON Submit
  const handleProcessPastedJSON = () => {
    if (!pastedText.trim()) return;
    const res = validateAndNormalizeJSON(pastedText);
    if (res.valid && res.normalizedState) {
      setImportPreview(res);
      setConfirmReplaceModal(res.normalizedState);
      setPasteJSONModalOpen(false);
    } else {
      alert(res.error || 'Invalid tracker JSON.');
    }
  };

  // Confirm and Apply Import
  const handleConfirmImport = () => {
    if (!confirmReplaceModal) return;
    onApplyImportedState(confirmReplaceModal);
    setConfirmReplaceModal(null);
    setImportPreview(null);
    setPastedText('');
  };

  // Handle Save New Profile
  const handleSaveNewProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    onCreateProfile(newProfileName.trim(), Number(newTargetScore) || 95);
    setNewProfileName('');
    setIsNewProfileModalOpen(false);
  };

  // Handle Save Edit Profile
  const handleSaveEditProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editProfileModal || !editProfileName.trim()) return;
    onUpdateProfile(editProfileModal.id, editProfileName.trim(), Number(editTargetScore) || 95);
    setEditProfileModal(null);
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Official App Branding Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 border border-blue-900/60 shadow-xl text-white flex flex-col sm:flex-row items-center gap-5">
        <div className="w-20 h-20 rounded-full overflow-hidden shadow-2xl ring-4 ring-blue-500/30 bg-slate-900 shrink-0">
          <img
            src="/logo.png"
            alt="Ansh Bhaiya CBSE Tracker Logo"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="text-center sm:text-left space-y-1 min-w-0">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
            <Sparkles className="w-3 h-3 text-cyan-400" /> Plan • Track • Achieve
          </div>
          <h1 className="text-lg md:text-xl font-black text-white">
            ANSH BHAIYA CBSE TRACKER
          </h1>
          <p className="text-xs text-slate-300">
            CBSE Class 10 Board 2027 • Offline IndexedDB • Supabase Email Auth
          </p>
        </div>
      </div>

      {/* SECTION 1: PROFILES MANAGEMENT */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-500" />
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Student Profiles ({appState.profiles.length})
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Each profile has independent chapters, datesheet, and streak
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setNewProfileName('');
              setNewTargetScore(95);
              setIsNewProfileModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm shadow-indigo-600/30 transition active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Profile</span>
          </button>
        </div>

        <div className="space-y-2">
          {appState.profiles.map((p) => {
            const isSelected = p.id === activeProfile.id;
            const chapterCount = p.subjects.reduce((sum, s) => sum + s.chapters.length, 0);

            return (
              <div
                key={p.id}
                className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'border-indigo-500/50 bg-indigo-50/50 dark:bg-indigo-950/20'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                }`}
              >
                <div
                  onClick={() => onSelectProfile(p.id)}
                  className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                >
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-white font-extrabold flex items-center justify-center text-sm shadow-sm shrink-0">
                    {p.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                        {p.name}
                      </span>
                      {isSelected && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500 text-white">
                          Active
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Target: {p.targetScore}% • {chapterCount} chapters • {p.currentStreak}d streak
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setEditProfileModal(p);
                      setEditProfileName(p.name);
                      setEditTargetScore(p.targetScore);
                    }}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition"
                    title="Edit profile"
                  >
                    Edit
                  </button>

                  {appState.profiles.length > 1 && (
                    <button
                      onClick={() => setDeleteProfileId(p.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg transition"
                      title="Delete profile"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: JSON IMPORT & EXPORT (VERY IMPORTANT FEATURE) */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <FileCode className="w-5 h-5 text-indigo-500" />
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              JSON Import & Export
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Supports Ansh Bhaiya & Sunil Bhaiya CBSE Tracker JSON files with safe verification.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Export Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                <Download className="w-4 h-4" />
                <span>Export Tracker JSON</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Save complete backup including all profiles, chapter progress, streak, datesheet, and notes.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleExportDownload}
                className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/20 active:scale-95 transition flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .JSON</span>
              </button>
              <button
                onClick={handleCopyJSON}
                className="py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 transition flex items-center gap-1"
                title="Copy JSON string to clipboard"
              >
                {copiedSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Import Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                <Upload className="w-4 h-4" />
                <span>Import Tracker JSON</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Restore existing data from file or paste JSON code. Validates before applying.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="file"
                ref={fileInputRef}
                accept=".json,application/json"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-bold shadow-md active:scale-95 transition flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload File</span>
              </button>
              <button
                onClick={() => setPasteJSONModalOpen(true)}
                className="py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 transition"
              >
                Paste Code
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: AUTOMATIC BACKUPS & LOCAL SNAPSHOTS */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-indigo-500" />
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Automatic IndexedDB Snapshots
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Local rollbacks created automatically as you study. Never lose your progress.
            </p>
          </div>
        </div>

        {backups.length === 0 ? (
          <div className="text-xs text-slate-500">
            Snapshots will appear here automatically as you track chapter tasks.
          </div>
        ) : (
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {backups.map((snap) => (
              <div
                key={snap.id}
                className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {snap.profileName} • {snap.chapterCount} Chapters
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {new Date(snap.timestamp).toLocaleString()} • {snap.completedTasksCount} tasks done
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (confirm(`Restore snapshot from ${new Date(snap.timestamp).toLocaleString()}? Current state will be replaced.`)) {
                      onRestoreSnapshot(snap);
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                >
                  Restore
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION 4: APP & STORAGE INFO */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-500" />
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Offline PWA Storage & Android APK
              </h3>
              <p className="text-xs text-slate-500">
                100% offline enabled via IndexedDB & Service Worker
              </p>
            </div>
          </div>
          <PWAInstallButton />
        </div>

        {/* Android APK Preparation Box */}
        <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60 space-y-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-blue-600 dark:text-blue-400">
            <Smartphone className="w-4 h-4" />
            <span>Ready for Android APK Generation (PWA Builder / TWA)</span>
          </div>
          <p className="text-slate-600 dark:text-slate-300">
            This app is pre-configured with a valid Web App Manifest, official Ansh Bhaiya icons (192px, 512px, maskable), theme color <code className="bg-slate-200 dark:bg-slate-800 px-1 rounded">#0a0f1d</code>, and background caching for offline operation.
          </p>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-0.5">
            <div>• <strong>Method 1 (Instant):</strong> Tap "Install App" or "Add to Home screen" in Chrome for Android.</div>
            <div>• <strong>Method 2 (Play Store / Signed APK):</strong> Enter this app's URL on <a href="https://pwabuilder.com" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold">PWABuilder.com</a> or use Google's <code className="bg-slate-200 dark:bg-slate-800 px-1 rounded">@bubblewrap/cli</code>.</div>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
          <span className="text-xs text-rose-500 font-semibold">Danger Zone</span>
          <button
            onClick={() => setConfirmResetOpen(true)}
            className="text-xs font-bold text-rose-500 hover:text-rose-600 hover:underline"
          >
            Reset All Tracker Data
          </button>
        </div>
      </div>

      {/* MODAL: CREATE PROFILE */}
      {isNewProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Create Student Profile
            </h3>
            <form onSubmit={handleSaveNewProfile} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Student Name
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  placeholder="e.g. Ansh - Class 10"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Target Score Percentage (%)
                </label>
                <input
                  type="number"
                  min={50}
                  max={100}
                  value={newTargetScore}
                  onChange={(e) => setNewTargetScore(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewProfileModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                >
                  Create Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT PROFILE */}
      {editProfileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Edit Student Profile
            </h3>
            <form onSubmit={handleSaveEditProfile} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Student Name
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  value={editProfileName}
                  onChange={(e) => setEditProfileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Target Score Percentage (%)
                </label>
                <input
                  type="number"
                  min={50}
                  max={100}
                  value={editTargetScore}
                  onChange={(e) => setEditTargetScore(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditProfileModal(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DELETE PROFILE CONFIRMATION */}
      {deleteProfileId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-3">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Delete Profile?
            </h3>
            <p className="text-xs text-slate-500">
              Are you sure you want to delete this profile? All chapters and progress in this profile will be removed.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteProfileId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteProfile(deleteProfileId);
                  setDeleteProfileId(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 text-white"
              >
                Delete Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: PASTE JSON */}
      {pasteJSONModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Paste Tracker JSON
            </h3>
            <p className="text-xs text-slate-500">
              Paste the exported JSON text from Ansh Bhaiya or Sunil Bhaiya CBSE Tracker below.
            </p>

            <textarea
              rows={8}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder='Paste JSON here, e.g. {"appName": "Ansh Bhaiya CBSE Tracker", ...}'
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setPasteJSONModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleProcessPastedJSON}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white"
              >
                Verify & Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRM IMPORT (Never erase without confirmation) */}
      {confirmReplaceModal && importPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Confirm JSON Import
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                A valid tracker file was verified from{' '}
                <strong className="text-indigo-600 dark:text-indigo-400 capitalize">
                  {importPreview.sourceType === 'sunil_bhaiya' ? 'Sunil Bhaiya CBSE Tracker' : 'Ansh Bhaiya Tracker'}
                </strong>.
              </p>
            </div>

            {/* Stats preview */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Profiles to Import:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {importPreview.stats?.profilesCount}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Chapters:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {importPreview.stats?.totalChapters}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Completed Chapters:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  {importPreview.stats?.completedChapters}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">
              ⚠️ Applying this import will replace your active tracker with the imported dataset. (An automatic backup of your current tracker has been created).
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setConfirmReplaceModal(null);
                  setImportPreview(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmImport}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
              >
                Confirm & Apply Import
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RESET CONFIRMATION */}
      {confirmResetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-3">
            <h3 className="text-base font-bold text-rose-600">
              Reset All Tracker Data?
            </h3>
            <p className="text-xs text-slate-500">
              This will reset the tracker to an empty state. All chapters, streak, datesheet, and notes will be cleared.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmResetOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onResetAllData();
                  setConfirmResetOpen(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 text-white"
              >
                Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
