import React, { useState } from 'react';
import {
  ShieldAlert,
  Edit3,
  Plus,
  Trash2,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Flame,
  BookOpen,
  Lock,
  Download,
  Check,
  X,
  Palette,
  Award,
} from 'lucide-react';
import { Profile, Subject, TaskState } from '../../types';
import { downloadTrackerJSON } from '../../utils/jsonHandler';
import { AppState } from '../../types';

interface AdminControlCenterProps {
  isOpen: boolean;
  onClose: () => void;
  appState: AppState;
  activeProfile: Profile;
  onUpdateProfileNameAndTarget: (name: string, targetScore: number) => void;
  onOverrideStreak: (currentStreak: number, longestStreak: number) => void;
  onAddSubject: (name: string, color: string) => void;
  onEditSubject: (subjectId: string, name: string, color: string) => void;
  onDeleteSubject: (subjectId: string) => void;
  onBatchSetSubjectChapters: (subjectId: string, state: TaskState) => void;
  onLoadOfficialSyllabus: () => void;
}

const COLOR_PRESETS = [
  { label: 'Emerald / Green', value: 'from-emerald-500 to-teal-600' },
  { label: 'Blue / Indigo', value: 'from-blue-500 to-indigo-600' },
  { label: 'Amber / Orange', value: 'from-amber-500 to-orange-600' },
  { label: 'Purple / Violet', value: 'from-purple-500 to-violet-600' },
  { label: 'Rose / Pink', value: 'from-rose-500 to-pink-600' },
  { label: 'Cyan / Sky', value: 'from-cyan-500 to-blue-500' },
  { label: 'Fuchsia / Purple', value: 'from-fuchsia-500 to-purple-600' },
];

export const AdminControlCenter: React.FC<AdminControlCenterProps> = ({
  isOpen,
  onClose,
  appState,
  activeProfile,
  onUpdateProfileNameAndTarget,
  onOverrideStreak,
  onAddSubject,
  onEditSubject,
  onDeleteSubject,
  onBatchSetSubjectChapters,
  onLoadOfficialSyllabus,
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'subjects' | 'streak' | 'syllabus' | 'privacy'>('subjects');

  // Streak override form
  const [overrideCurrent, setOverrideCurrent] = useState(activeProfile.currentStreak);
  const [overrideLongest, setOverrideLongest] = useState(activeProfile.longestStreak);
  const [streakSuccess, setStreakSuccess] = useState(false);

  // Profile target form
  const [profName, setProfName] = useState(activeProfile.name);
  const [profTarget, setProfTarget] = useState(activeProfile.targetScore);
  const [profSuccess, setProfSuccess] = useState(false);

  // Subject Modal states
  const [isAddSubjectOpen, setIsAddSubjectOpen] = useState(false);
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectColor, setNewSubjectColor] = useState(COLOR_PRESETS[0].value);

  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [editSubjectName, setEditSubjectName] = useState('');
  const [editSubjectColor, setEditSubjectColor] = useState('');

  if (!isOpen) return null;

  const handleSaveStreak = (e: React.FormEvent) => {
    e.preventDefault();
    onOverrideStreak(Number(overrideCurrent), Number(overrideLongest));
    setStreakSuccess(true);
    setTimeout(() => setStreakSuccess(false), 2000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfileNameAndTarget(profName, Number(profTarget));
    setProfSuccess(true);
    setTimeout(() => setProfSuccess(false), 2000);
  };

  const handleCreateSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubjectName.trim()) return;
    onAddSubject(newSubjectName.trim(), newSubjectColor);
    setNewSubjectName('');
    setIsAddSubjectOpen(false);
  };

  const handleSaveEditSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubject || !editSubjectName.trim()) return;
    onEditSubject(editingSubject.id, editSubjectName.trim(), editSubjectColor);
    setEditingSubject(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-amber-500/30 dark:border-amber-500/40 shadow-2xl overflow-hidden">
        {/* Admin Header */}
        <div className="p-5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black/20 flex items-center justify-center text-amber-200">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black tracking-tight">Admin Master Control Panel</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-black/30 text-amber-200 border border-amber-300/30">
                  Full Access
                </span>
              </div>
              <p className="text-xs text-amber-100">
                Logged in as <strong>ansh666960@gmail.com</strong> (Private Partition)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Admin Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 overflow-x-auto no-scrollbar shrink-0">
          <button
            onClick={() => setActiveAdminTab('subjects')}
            className={`px-4 py-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
              activeAdminTab === 'subjects'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Manage Subjects ({activeProfile.subjects.length})
          </button>
          <button
            onClick={() => setActiveAdminTab('streak')}
            className={`px-4 py-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
              activeAdminTab === 'streak'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Streak & Targets Override
          </button>
          <button
            onClick={() => setActiveAdminTab('syllabus')}
            className={`px-4 py-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
              activeAdminTab === 'syllabus'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Batch Chapter Operations
          </button>
          <button
            onClick={() => setActiveAdminTab('privacy')}
            className={`px-4 py-3 text-xs font-bold whitespace-nowrap transition-colors border-b-2 ${
              activeAdminTab === 'privacy'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Privacy Shield (Zero Share)
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: SUBJECTS MANAGEMENT */}
          {activeAdminTab === 'subjects' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Edit, Add or Reorder Subjects
                  </h3>
                  <p className="text-xs text-slate-500">
                    As Admin, you can add custom subjects (like Sanskrit, IT, Computer) or customize any existing subject.
                  </p>
                </div>
                <button
                  onClick={() => setIsAddSubjectOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-md active:scale-95 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Subject</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {activeProfile.subjects.map((sub, index) => (
                  <div
                    key={sub.id}
                    className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${sub.color} flex items-center justify-center text-white font-extrabold text-xs shadow-sm`}
                      >
                        {sub.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 dark:text-white">
                          {sub.name}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {sub.chapters.length} chapters
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setEditingSubject(sub);
                          setEditSubjectName(sub.name);
                          setEditSubjectColor(sub.color);
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-bold text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40"
                      >
                        Edit
                      </button>
                      {activeProfile.subjects.length > 1 && (
                        <button
                          onClick={() => {
                            if (confirm(`Delete subject "${sub.name}" and all its chapters?`)) {
                              onDeleteSubject(sub.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg transition"
                          title="Delete subject"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: STREAK & TARGETS OVERRIDE */}
          {activeAdminTab === 'streak' && (
            <div className="space-y-6">
              {/* Streak Override */}
              <form onSubmit={handleSaveStreak} className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Manual Streak Override
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Manually adjust active study days and longest streak records.
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Current Streak (Days)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={999}
                      value={overrideCurrent}
                      onChange={(e) => setOverrideCurrent(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Longest Streak (Days)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={999}
                      value={overrideLongest}
                      onChange={(e) => setOverrideLongest(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono font-bold"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-md flex items-center gap-1.5"
                >
                  {streakSuccess ? <Check className="w-4 h-4 text-emerald-200" /> : <Edit3 className="w-4 h-4" />}
                  <span>{streakSuccess ? 'Streak Saved!' : 'Apply Streak Override'}</span>
                </button>
              </form>

              {/* Profile Details Override */}
              <form onSubmit={handleSaveProfile} className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-4">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-indigo-500" />
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Profile Target & Display Name
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Display Name
                    </label>
                    <input
                      type="text"
                      value={profName}
                      onChange={(e) => setProfName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Target Score (%)
                    </label>
                    <input
                      type="number"
                      min={50}
                      max={100}
                      value={profTarget}
                      onChange={(e) => setProfTarget(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono font-bold"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md flex items-center gap-1.5"
                >
                  {profSuccess ? <Check className="w-4 h-4 text-emerald-200" /> : <Edit3 className="w-4 h-4" />}
                  <span>{profSuccess ? 'Saved!' : 'Save Target Details'}</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: BATCH CHAPTER OPERATIONS */}
          {activeAdminTab === 'syllabus' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                  Batch Task Completion per Subject
                </h3>
                <p className="text-xs text-slate-500">
                  Quickly mark all 7 tasks across all chapters in a subject as Completed, or Reset to Not Started.
                </p>

                <div className="space-y-2">
                  {activeProfile.subjects.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                    >
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        {sub.name} ({sub.chapters.length} ch)
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            if (confirm(`Mark ALL tasks in all ${sub.chapters.length} chapters of ${sub.name} as Completed?`)) {
                              onBatchSetSubjectChapters(sub.id, 'completed');
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500 text-white text-[11px] font-bold hover:bg-emerald-600"
                        >
                          Mark All Done
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Reset all tasks in ${sub.name} to Not Started?`)) {
                              onBatchSetSubjectChapters(sub.id, 'not_started');
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-[11px] font-medium hover:bg-slate-100"
                        >
                          Reset
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/60 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                    Reload Official CBSE Class 10 Syllabus
                  </h4>
                  <p className="text-[11px] text-indigo-700 dark:text-indigo-400">
                    Overwrites with all official Class 10 NCERT chapters (Science, Maths, SST, English, Hindi).
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (confirm('Reload official NCERT syllabus chapters for all subjects?')) {
                      onLoadOfficialSyllabus();
                    }
                  }}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 shadow-md"
                >
                  Reload All
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: PRIVACY SHIELD (ZERO DATA SHARING) */}
          {activeAdminTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-5 rounded-3xl bg-emerald-500/10 border border-emerald-500/30 space-y-3">
                <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                  <Lock className="w-5 h-5" />
                  <span>Admin Privacy Shield Active (100% Isolated Data)</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  As requested, <strong>admin ka koi bhi data share nahi hoga</strong>. Your progress, chapters, study notes, streak, and revision tasks are strictly saved under your private user partition:
                </p>
                <div className="p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs">
                  Storage Partition: current_state_admin_ansh666960_private
                </div>
                <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-1 list-disc pl-4">
                  <li>Student profiles cannot access your private admin tracker records.</li>
                  <li>Guest/offline users are completely separated into an isolated storage partition.</li>
                  <li>When you sign out, your admin session is wiped from active memory.</li>
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    Download Admin Private JSON Backup
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Export your private admin dataset to an offline encrypted file.
                  </p>
                </div>
                <button
                  onClick={() => downloadTrackerJSON(appState)}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold flex items-center gap-1.5 shadow-md"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export JSON</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* MODAL: ADD SUBJECT */}
        {isAddSubjectOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Add Custom Subject
              </h3>
              <form onSubmit={handleCreateSubject} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Subject Name
                  </label>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="e.g. Sanskrit, Computer Applications"
                    value={newSubjectName}
                    onChange={(e) => setNewSubjectName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Theme Color
                  </label>
                  <select
                    value={newSubjectColor}
                    onChange={(e) => setNewSubjectColor(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    {COLOR_PRESETS.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddSubjectOpen(false)}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-white shadow-md"
                  >
                    Create Subject
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL: EDIT SUBJECT */}
        {editingSubject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Edit Subject Details
              </h3>
              <form onSubmit={handleSaveEditSubject} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Subject Name
                  </label>
                  <input
                    type="text"
                    required
                    value={editSubjectName}
                    onChange={(e) => setEditSubjectName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Theme Color
                  </label>
                  <select
                    value={editSubjectColor}
                    onChange={(e) => setEditSubjectColor(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    {COLOR_PRESETS.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingSubject(null)}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-amber-500 text-white shadow-md"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
