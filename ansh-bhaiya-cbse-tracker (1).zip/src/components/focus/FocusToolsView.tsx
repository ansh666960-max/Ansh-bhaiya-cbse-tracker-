import React, { useState, useEffect, useRef, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  Play,
  Pause,
  RotateCcw,
  Flag,
  Bell,
  Clock,
  Timer,
  CheckCircle2,
  TrendingUp,
  Calendar,
  Sparkles,
  BarChart3,
  Award,
  Volume2,
} from 'lucide-react';
import { StudySession, StopwatchLap, Subject } from '../../types';
import {
  playTimerCompletionChime,
  playLapChime,
  requestNotificationPermission,
  sendTimerCompletionNotification,
} from '../../utils/timerAudio';
import { getTodayDateString, formatDateToLocal } from '../../utils/streak';

interface FocusToolsViewProps {
  subjects: Subject[];
  studySessions: StudySession[];
  onRecordStudySession: (session: Omit<StudySession, 'id'>) => void;
}

const TIMER_STORAGE_KEY = 'ansh_cbse_timer_state_v1';
const STOPWATCH_STORAGE_KEY = 'ansh_cbse_stopwatch_state_v1';

export const FocusToolsView: React.FC<FocusToolsViewProps> = ({
  subjects,
  studySessions,
  onRecordStudySession,
}) => {
  const [activeTool, setActiveTool] = useState<'timer' | 'stopwatch'>('timer');

  // --- TIMER STATE ---
  const [timerPresetMinutes, setTimerPresetMinutes] = useState<number>(25);
  const [timerDurationSeconds, setTimerDurationSeconds] = useState<number>(25 * 60);
  const [timerRemainingSeconds, setTimerRemainingSeconds] = useState<number>(25 * 60);
  const [timerIsRunning, setTimerIsRunning] = useState<boolean>(false);
  const [timerSubject, setTimerSubject] = useState<string>('Science');
  const [customMinutesInput, setCustomMinutesInput] = useState<string>('');
  const [showCustomModal, setShowCustomModal] = useState<boolean>(false);
  const [notificationGranted, setNotificationGranted] = useState<boolean>(false);

  const timerTargetEndRef = useRef<number | null>(null);

  // --- STOPWATCH STATE ---
  const [stopwatchElapsedMs, setStopwatchElapsedMs] = useState<number>(0);
  const [stopwatchIsRunning, setStopwatchIsRunning] = useState<boolean>(false);
  const [stopwatchLaps, setStopwatchLaps] = useState<StopwatchLap[]>([]);
  const stopwatchStartRef = useRef<number | null>(null);
  const stopwatchBaseElapsedRef = useRef<number>(0);

  // Check notification permission on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationGranted(Notification.permission === 'granted');
    }
  }, []);

  // Restore Timer state from localStorage on load
  useEffect(() => {
    try {
      const savedTimer = localStorage.getItem(TIMER_STORAGE_KEY);
      if (savedTimer) {
        const parsed = JSON.parse(savedTimer);
        const totalDuration = parsed.durationSeconds || 25 * 60;
        setTimerDurationSeconds(totalDuration);
        setTimerPresetMinutes(Math.round(totalDuration / 60));
        if (parsed.subject) setTimerSubject(parsed.subject);

        if (parsed.isRunning && parsed.targetEndTimeMs) {
          const now = Date.now();
          if (now < parsed.targetEndTimeMs) {
            const diffSec = Math.max(0, Math.round((parsed.targetEndTimeMs - now) / 1000));
            setTimerRemainingSeconds(diffSec);
            setTimerIsRunning(true);
            timerTargetEndRef.current = parsed.targetEndTimeMs;
          } else {
            // Already expired while away
            setTimerRemainingSeconds(0);
            setTimerIsRunning(false);
          }
        } else {
          setTimerRemainingSeconds(parsed.remainingSeconds ?? totalDuration);
          setTimerIsRunning(false);
        }
      }
    } catch {
      // ignore
    }

    // Restore Stopwatch state
    try {
      const savedSw = localStorage.getItem(STOPWATCH_STORAGE_KEY);
      if (savedSw) {
        const parsed = JSON.parse(savedSw);
        setStopwatchLaps(parsed.laps || []);
        if (parsed.isRunning && parsed.startTimeMs) {
          const now = Date.now();
          const runningElapsed = now - parsed.startTimeMs + (parsed.baseElapsedMs || 0);
          setStopwatchElapsedMs(runningElapsed);
          stopwatchBaseElapsedRef.current = parsed.baseElapsedMs || 0;
          stopwatchStartRef.current = parsed.startTimeMs;
          setStopwatchIsRunning(true);
        } else {
          const base = parsed.elapsedMs || 0;
          setStopwatchElapsedMs(base);
          stopwatchBaseElapsedRef.current = base;
          setStopwatchIsRunning(false);
        }
      }
    } catch {
      // ignore
    }
  }, []);

  // Save Timer state on change
  useEffect(() => {
    try {
      localStorage.setItem(
        TIMER_STORAGE_KEY,
        JSON.stringify({
          durationSeconds: timerDurationSeconds,
          remainingSeconds: timerRemainingSeconds,
          isRunning: timerIsRunning,
          targetEndTimeMs: timerTargetEndRef.current,
          subject: timerSubject,
        })
      );
    } catch {
      // ignore
    }
  }, [timerDurationSeconds, timerRemainingSeconds, timerIsRunning, timerSubject]);

  // Save Stopwatch state on change
  useEffect(() => {
    try {
      localStorage.setItem(
        STOPWATCH_STORAGE_KEY,
        JSON.stringify({
          elapsedMs: stopwatchElapsedMs,
          baseElapsedMs: stopwatchBaseElapsedRef.current,
          isRunning: stopwatchIsRunning,
          startTimeMs: stopwatchStartRef.current,
          laps: stopwatchLaps,
        })
      );
    } catch {
      // ignore
    }
  }, [stopwatchElapsedMs, stopwatchIsRunning, stopwatchLaps]);

  // Timer Tick Engine (Drift-free timestamp comparison)
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;

    if (timerIsRunning) {
      if (!timerTargetEndRef.current) {
        timerTargetEndRef.current = Date.now() + timerRemainingSeconds * 1000;
      }

      intervalId = setInterval(() => {
        const now = Date.now();
        if (timerTargetEndRef.current) {
          const remaining = Math.max(0, Math.round((timerTargetEndRef.current - now) / 1000));
          setTimerRemainingSeconds(remaining);

          if (remaining <= 0) {
            setTimerIsRunning(false);
            timerTargetEndRef.current = null;

            // Trigger Chime & Notification & Confetti
            playTimerCompletionChime();
            const sessionMins = Math.round(timerDurationSeconds / 60);
            sendTimerCompletionNotification(timerSubject, sessionMins);
            try {
              confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
            } catch {
              // ignore
            }

            // Record session automatically
            onRecordStudySession({
              durationMinutes: sessionMins,
              subject: timerSubject,
              completedAt: new Date().toISOString(),
              type: 'timer',
            });
          }
        }
      }, 500);
    } else {
      timerTargetEndRef.current = null;
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [timerIsRunning, timerRemainingSeconds, timerDurationSeconds, timerSubject, onRecordStudySession]);

  // Stopwatch Tick Engine
  useEffect(() => {
    let animFrame: number;

    const tick = () => {
      if (stopwatchStartRef.current) {
        const now = Date.now();
        const currentElapsed = stopwatchBaseElapsedRef.current + (now - stopwatchStartRef.current);
        setStopwatchElapsedMs(currentElapsed);
      }
      animFrame = requestAnimationFrame(tick);
    };

    if (stopwatchIsRunning) {
      animFrame = requestAnimationFrame(tick);
    }

    return () => cancelAnimationFrame(animFrame);
  }, [stopwatchIsRunning]);

  // Timer Handlers
  const handleSelectPreset = (mins: number) => {
    setTimerIsRunning(false);
    timerTargetEndRef.current = null;
    setTimerPresetMinutes(mins);
    setTimerDurationSeconds(mins * 60);
    setTimerRemainingSeconds(mins * 60);
  };

  const handleStartTimer = async () => {
    if (timerRemainingSeconds <= 0) {
      setTimerRemainingSeconds(timerDurationSeconds);
    }
    timerTargetEndRef.current = Date.now() + (timerRemainingSeconds > 0 ? timerRemainingSeconds : timerDurationSeconds) * 1000;
    setTimerIsRunning(true);

    // Request notification permission if not yet decided
    if (!notificationGranted) {
      const granted = await requestNotificationPermission();
      setNotificationGranted(granted);
    }
  };

  const handlePauseTimer = () => {
    setTimerIsRunning(false);
    timerTargetEndRef.current = null;
  };

  const handleResetTimer = () => {
    setTimerIsRunning(false);
    timerTargetEndRef.current = null;
    setTimerRemainingSeconds(timerDurationSeconds);
  };

  const handleApplyCustomMinutes = (e: React.FormEvent) => {
    e.preventDefault();
    const mins = parseInt(customMinutesInput, 10);
    if (!isNaN(mins) && mins > 0 && mins <= 240) {
      handleSelectPreset(mins);
      setShowCustomModal(false);
      setCustomMinutesInput('');
    }
  };

  // Stopwatch Handlers
  const handleStartStopwatch = () => {
    stopwatchStartRef.current = Date.now();
    setStopwatchIsRunning(true);
  };

  const handlePauseStopwatch = () => {
    if (stopwatchStartRef.current) {
      const now = Date.now();
      const current = stopwatchBaseElapsedRef.current + (now - stopwatchStartRef.current);
      stopwatchBaseElapsedRef.current = current;
      setStopwatchElapsedMs(current);
    }
    stopwatchStartRef.current = null;
    setStopwatchIsRunning(false);
  };

  const handleResetStopwatch = () => {
    setStopwatchIsRunning(false);
    stopwatchStartRef.current = null;
    stopwatchBaseElapsedRef.current = 0;
    setStopwatchElapsedMs(0);
    setStopwatchLaps([]);
  };

  const handleRecordLap = () => {
    playLapChime();
    const lapNumber = stopwatchLaps.length + 1;
    const splitTimeMs = stopwatchElapsedMs;
    const previousSplit = stopwatchLaps.length > 0 ? stopwatchLaps[0].splitTimeMs : 0;
    const lapTimeMs = splitTimeMs - previousSplit;

    const newLap: StopwatchLap = {
      id: `lap-${Date.now()}-${lapNumber}`,
      lapNumber,
      lapTimeMs,
      splitTimeMs,
    };

    setStopwatchLaps([newLap, ...stopwatchLaps]);
  };

  // Format Helpers
  const formatTimerTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const formatStopwatchTime = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const hours = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    const centis = Math.floor((ms % 1000) / 10);

    if (hours > 0) {
      return {
        main: `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`,
        ms: String(centis).padStart(2, '0'),
      };
    }
    return {
      main: `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`,
      ms: String(centis).padStart(2, '0'),
    };
  };

  // Calculate fastest and slowest lap IDs
  const { fastestLapId, slowestLapId } = useMemo(() => {
    if (stopwatchLaps.length < 2) return { fastestLapId: null, slowestLapId: null };
    let fastest = stopwatchLaps[0];
    let slowest = stopwatchLaps[0];

    stopwatchLaps.forEach((l) => {
      if (l.lapTimeMs < fastest.lapTimeMs) fastest = l;
      if (l.lapTimeMs > slowest.lapTimeMs) slowest = l;
    });

    return { fastestLapId: fastest.id, slowestLapId: slowest.id };
  }, [stopwatchLaps]);

  // Analytics Computations
  const todayStr = getTodayDateString();
  const todaySessions = studySessions.filter((s) => s.completedAt.startsWith(todayStr));
  const todayTotalMinutes = todaySessions.reduce((sum, s) => sum + s.durationMinutes, 0);

  // Past 7 Days Daily Breakdown
  const past7DaysData = useMemo(() => {
    const days: Array<{ dateStr: string; label: string; minutes: number }> = [];
    const now = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const dayNum = String(d.getDate()).padStart(2, '0');
      const dateStr = `${y}-${m}-${dayNum}`;

      const mins = studySessions
        .filter((s) => s.completedAt.startsWith(dateStr))
        .reduce((sum, s) => sum + s.durationMinutes, 0);

      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      days.push({ dateStr, label: i === 0 ? 'Today' : dayName, minutes: mins });
    }
    return days;
  }, [studySessions]);

  const weeklyTotalMinutes = past7DaysData.reduce((sum, d) => sum + d.minutes, 0);
  const maxDailyMinutes = Math.max(60, ...past7DaysData.map((d) => d.minutes));

  // Timer Progress Calculation for circular ring
  const timerPercentage =
    timerDurationSeconds > 0
      ? Math.max(0, Math.min(100, (timerRemainingSeconds / timerDurationSeconds) * 100))
      : 0;

  return (
    <div className="space-y-6 pb-28 animate-in fade-in duration-300">
      {/* Top Header Switcher: Timer vs Stopwatch */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setActiveTool('timer')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTool === 'timer'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Timer className="w-4 h-4" />
            <span>Study Timer</span>
          </button>
          <button
            onClick={() => setActiveTool('stopwatch')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTool === 'stopwatch'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Stopwatch</span>
          </button>
        </div>

        {/* Notification indicator */}
        <button
          onClick={async () => {
            const granted = await requestNotificationPermission();
            setNotificationGranted(granted);
          }}
          className={`p-2 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition ${
            notificationGranted
              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-500 hover:border-slate-300'
          }`}
          title={notificationGranted ? 'Notifications enabled' : 'Enable browser study completion notifications'}
        >
          <Bell className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{notificationGranted ? 'Alerts ON' : 'Enable Alerts'}</span>
        </button>
      </div>

      {/* --- TOOL 1: STUDY TIMER --- */}
      {activeTool === 'timer' && (
        <div className="space-y-6">
          {/* Main Timer Dial Card */}
          <div className="p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden">
            {/* Background subtle glow */}
            <div className="absolute w-64 h-64 rounded-full bg-blue-500/5 dark:bg-blue-500/10 blur-3xl pointer-events-none" />

            {/* Subject Selector Pill */}
            <div className="mb-4">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Study Subject Tag
              </label>
              <select
                value={timerSubject}
                onChange={(e) => setTimerSubject(e.target.value)}
                disabled={timerIsRunning}
                className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name}
                  </option>
                ))}
                <option value="General Revision">General Revision</option>
                <option value="Sample Paper Test">Sample Paper Test</option>
              </select>
            </div>

            {/* Circular Countdown Ring */}
            <div className="relative my-2">
              <svg width={240} height={240} className="transform -rotate-90">
                <circle
                  cx={120}
                  cy={120}
                  r={104}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={12}
                  className="text-slate-100 dark:text-slate-800 transition-colors"
                />
                <circle
                  cx={120}
                  cy={120}
                  r={104}
                  fill="none"
                  stroke="url(#timerGradient)"
                  strokeWidth={12}
                  strokeDasharray={2 * Math.PI * 104}
                  strokeDashoffset={2 * Math.PI * 104 * (1 - timerPercentage / 100)}
                  strokeLinecap="round"
                  className="transition-all duration-500 ease-out"
                />
                <defs>
                  <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#38bdf8" />
                    <stop offset="50%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#10b981" />
                  </linearGradient>
                </defs>
              </svg>

              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 dark:text-white font-mono">
                  {formatTimerTime(timerRemainingSeconds)}
                </span>
                <span className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-wider">
                  {timerIsRunning ? 'Focusing...' : timerRemainingSeconds === 0 ? 'Completed!' : 'Paused'}
                </span>
              </div>
            </div>

            {/* Presets Row */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4 max-w-sm">
              {[25, 45, 60, 90].map((mins) => (
                <button
                  key={mins}
                  onClick={() => handleSelectPreset(mins)}
                  disabled={timerIsRunning}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 ${
                    timerPresetMinutes === mins
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  } ${timerIsRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {mins} min
                </button>
              ))}
              <button
                onClick={() => setShowCustomModal(true)}
                disabled={timerIsRunning}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
                  timerIsRunning ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                Custom
              </button>
            </div>

            {/* Controls Row */}
            <div className="flex items-center gap-3 mt-6">
              {!timerIsRunning ? (
                <button
                  onClick={handleStartTimer}
                  className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-blue-500/25 hover:from-blue-500 hover:to-indigo-500 active:scale-95 transition"
                >
                  <Play className="w-5 h-5 fill-white" />
                  <span>{timerRemainingSeconds < timerDurationSeconds ? 'Resume' : 'Start Focus'}</span>
                </button>
              ) : (
                <button
                  onClick={handlePauseTimer}
                  className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-amber-500 text-white font-bold text-sm shadow-lg shadow-amber-500/25 hover:bg-amber-600 active:scale-95 transition"
                >
                  <Pause className="w-5 h-5 fill-white" />
                  <span>Pause</span>
                </button>
              )}

              <button
                onClick={handleResetTimer}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition active:scale-95"
                title="Reset timer"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- TOOL 2: STOPWATCH --- */}
      {activeTool === 'stopwatch' && (
        <div className="space-y-6">
          <div className="p-6 md:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center">
            {/* Stopwatch Big Display */}
            <div className="my-6">
              <div className="flex items-baseline justify-center font-mono font-black text-slate-900 dark:text-white">
                <span className="text-5xl md:text-6xl tracking-tight">
                  {formatStopwatchTime(stopwatchElapsedMs).main}
                </span>
                <span className="text-2xl md:text-3xl text-blue-500 ml-1">
                  .{formatStopwatchTime(stopwatchElapsedMs).ms}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-2 font-medium">
                Accurate millisecond stopwatch with lap splits
              </p>
            </div>

            {/* Stopwatch Controls */}
            <div className="flex items-center gap-3">
              {!stopwatchIsRunning ? (
                <button
                  onClick={handleStartStopwatch}
                  className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-sm shadow-lg shadow-blue-500/25 active:scale-95 transition"
                >
                  <Play className="w-5 h-5 fill-white" />
                  <span>{stopwatchElapsedMs > 0 ? 'Resume' : 'Start'}</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={handleRecordLap}
                    className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900 font-bold text-sm shadow-md active:scale-95 transition"
                  >
                    <Flag className="w-4 h-4" />
                    <span>Lap</span>
                  </button>
                  <button
                    onClick={handlePauseStopwatch}
                    className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-500 text-white font-bold text-sm shadow-md active:scale-95 transition"
                  >
                    <Pause className="w-5 h-5 fill-white" />
                    <span>Pause</span>
                  </button>
                </>
              )}

              <button
                onClick={handleResetStopwatch}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition active:scale-95"
                title="Reset stopwatch"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Lap History List */}
          {stopwatchLaps.length > 0 && (
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
                <span>Lap ({stopwatchLaps.length})</span>
                <span>Lap Time</span>
                <span>Split Time</span>
              </div>

              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {stopwatchLaps.map((lap) => {
                  const isFastest = lap.id === fastestLapId;
                  const isSlowest = lap.id === slowestLapId;

                  return (
                    <div
                      key={lap.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-mono transition ${
                        isFastest
                          ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-bold'
                          : isSlowest
                          ? 'border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300 font-bold'
                          : 'border-slate-100 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span>Lap {lap.lapNumber}</span>
                        {isFastest && (
                          <span className="text-[10px] font-sans px-1.5 py-0.2 rounded bg-emerald-500 text-white font-bold">
                            Fastest
                          </span>
                        )}
                        {isSlowest && (
                          <span className="text-[10px] font-sans px-1.5 py-0.2 rounded bg-rose-500 text-white font-bold">
                            Slowest
                          </span>
                        )}
                      </div>

                      <span>
                        {formatStopwatchTime(lap.lapTimeMs).main}.{formatStopwatchTime(lap.lapTimeMs).ms}
                      </span>

                      <span className="text-slate-400">
                        {formatStopwatchTime(lap.splitTimeMs).main}.{formatStopwatchTime(lap.splitTimeMs).ms}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* --- SECTION 3: STUDY TIME ANALYTICS --- */}
      <div className="p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-500" />
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Study Time Analytics
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Completed focus timer sessions & time trends
              </p>
            </div>
          </div>
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-500">
            {studySessions.length} total sessions
          </span>
        </div>

        {/* 2 Big Stat Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-transparent border border-blue-500/20">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Today's Focus Time
            </div>
            <div className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">
              {Math.floor(todayTotalMinutes / 60)}h {todayTotalMinutes % 60}m
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {todaySessions.length} session{todaySessions.length !== 1 ? 's' : ''} completed
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Past 7 Days Total
            </div>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
              {Math.floor(weeklyTotalMinutes / 60)}h {weeklyTotalMinutes % 60}m
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Weekly consistency target</div>
          </div>
        </div>

        {/* 7-Day Bar Chart */}
        <div className="space-y-2 pt-2">
          <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Daily Study Time (Minutes)
          </h3>

          <div className="h-36 flex items-end gap-2 pt-6 pb-2">
            {past7DaysData.map((d, idx) => {
              const heightPercent = maxDailyMinutes > 0 ? (d.minutes / maxDailyMinutes) * 100 : 0;
              const isToday = idx === past7DaysData.length - 1;

              return (
                <div key={d.dateStr} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <span className="text-[10px] font-bold text-slate-400 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {d.minutes}m
                  </span>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-lg h-full flex items-end overflow-hidden p-0.5">
                    <div
                      className={`w-full rounded-md transition-all duration-500 ${
                        isToday
                          ? 'bg-gradient-to-t from-blue-600 to-cyan-400'
                          : 'bg-gradient-to-t from-indigo-500 to-blue-400'
                      }`}
                      style={{ height: `${Math.max(6, heightPercent)}%` }}
                    />
                  </div>
                  <span
                    className={`text-[10px] mt-2 font-semibold truncate ${
                      isToday ? 'text-blue-500 font-bold' : 'text-slate-400'
                    }`}
                  >
                    {d.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Session History List */}
        <div className="space-y-2 pt-2">
          <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Recent Study Sessions
          </h3>

          {studySessions.length === 0 ? (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 text-center text-xs text-slate-400">
              Start the Study Timer above. When it finishes, your completed session will automatically be recorded here!
            </div>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {studySessions.slice(0, 6).map((session) => (
                <div
                  key={session.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <div>
                      <div className="font-bold text-slate-800 dark:text-slate-200">
                        {session.subject}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(session.completedAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}{' '}
                        • {formatDateToLocal(session.completedAt.split('T')[0])}
                      </div>
                    </div>
                  </div>

                  <span className="font-bold text-blue-600 dark:text-blue-400">
                    +{session.durationMinutes} mins
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Custom Timer Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Set Custom Study Timer
            </h3>
            <form onSubmit={handleApplyCustomMinutes} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Duration (Minutes)
                </label>
                <input
                  type="number"
                  min={1}
                  max={240}
                  autoFocus
                  required
                  placeholder="e.g. 35"
                  value={customMinutesInput}
                  onChange={(e) => setCustomMinutesInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 text-white shadow-md shadow-blue-500/30"
                >
                  Set Timer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
