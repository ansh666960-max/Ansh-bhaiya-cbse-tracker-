import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Timer,
  CalendarDays,
  Flame,
  CheckSquare,
  Settings,
} from 'lucide-react';
import { NavTab } from '../../types';

interface BottomNavProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  pendingTasksCount?: number;
  streakCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  pendingTasksCount = 0,
  streakCount = 0,
}) => {
  const tabs = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'chapters' as NavTab, label: 'Chapters', icon: BookOpen },
    { id: 'focus' as NavTab, label: 'Focus', icon: Timer },
    { id: 'datesheet' as NavTab, label: 'Datesheet', icon: CalendarDays },
    { id: 'streak' as NavTab, label: 'Streak', icon: Flame, badge: streakCount > 0 ? `${streakCount}d` : undefined },
    { id: 'tasks' as NavTab, label: 'Tasks', icon: CheckSquare, badge: pendingTasksCount > 0 ? String(pendingTasksCount) : undefined },
    { id: 'settings' as NavTab, label: 'Settings', icon: Settings },
  ];

  const handleTabClick = (tabId: NavTab) => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(8);
      } catch {
        // ignore
      }
    }
    onChangeTab(tabId);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 pb-[env(safe-area-inset-bottom)] transition-colors">
      <div className="max-w-xl mx-auto flex items-center justify-around px-1 py-1.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`relative flex flex-col items-center justify-center flex-1 py-1.5 px-0.5 rounded-xl transition-all ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-bold scale-105'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'stroke-[2.5px]' : 'stroke-2'
                  }`}
                />
                {tab.badge && (
                  <span
                    className={`absolute -top-1.5 -right-2.5 min-w-[15px] h-3.5 px-1 rounded-full text-[8.5px] font-extrabold flex items-center justify-center ${
                      tab.id === 'streak'
                        ? 'bg-amber-500 text-white'
                        : 'bg-blue-600 text-white'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[9.5px] mt-1 tracking-tight truncate max-w-[48px]">
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute bottom-0 w-5 h-0.5 rounded-full bg-blue-600 dark:bg-blue-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
