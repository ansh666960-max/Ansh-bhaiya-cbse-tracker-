import React, { useState, useRef, useEffect } from 'react';
import { Sun, Moon, Users, Check, Plus, ChevronDown, UserCircle2, ShieldCheck, LogIn } from 'lucide-react';
import { Profile, AuthUser } from '../../types';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  profiles: Profile[];
  activeProfile: Profile;
  onSelectProfile: (id: string) => void;
  onOpenNewProfileModal: () => void;
  onNavigateToSettings: () => void;
  currentUser: AuthUser | null;
  onOpenAuthModal: () => void;
  isAdmin?: boolean;
  onOpenAdminCenter?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  onToggleTheme,
  profiles,
  activeProfile,
  onSelectProfile,
  onOpenNewProfileModal,
  onNavigateToSettings,
  currentUser,
  onOpenAuthModal,
  isAdmin = false,
  onOpenAdminCenter,
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-2">
        {/* Brand / Logo */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-full overflow-hidden shadow-md ring-2 ring-blue-500/30 bg-slate-900 flex items-center justify-center shrink-0">
            <img
              src="/logo.png"
              alt="Ansh Bhaiya CBSE Tracker Logo"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm md:text-base tracking-tight truncate text-slate-900 dark:text-white">
                Ansh Bhaiya
              </span>
              <span className="hidden sm:inline-flex px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-500 border border-blue-500/20">
                2027
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              CBSE Class 10 Tracker
            </p>
          </div>
        </div>

        {/* Right action group */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Admin Master Panel Button */}
          {isAdmin && (
            <button
              onClick={onOpenAdminCenter}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-600 dark:text-amber-400 font-extrabold text-xs shadow-sm hover:from-amber-500/30 hover:to-orange-500/30 active:scale-95 transition"
              title="Open Admin Master Control Center"
            >
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>Admin Panel</span>
            </button>
          )}

          {/* Auth Button */}
          <button
            onClick={onOpenAuthModal}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition active:scale-95 ${
              currentUser
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 hover:bg-slate-200/70'
            }`}
            title={currentUser ? `Signed in as ${currentUser.name}` : 'Sign In with Email'}
          >
            {currentUser ? (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span className="max-w-[70px] truncate">{currentUser.name.split(' ')[0]}</span>
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5 text-blue-500" />
                <span>Sign In</span>
              </>
            )}
          </button>

          {/* Profile Switcher */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-800/70 hover:bg-slate-200/70 dark:hover:bg-slate-700/70 text-xs font-semibold text-slate-700 dark:text-slate-200 transition"
              title="Switch or manage student profiles"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-[10px] text-white font-bold">
                {activeProfile.name.charAt(0).toUpperCase()}
              </div>
              <span className="max-w-[65px] md:max-w-[110px] truncate">
                {activeProfile.name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {profileDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl py-2 z-50">
                <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                    Student Profiles ({profiles.length})
                  </p>
                </div>

                <div className="max-h-56 overflow-y-auto py-1">
                  {profiles.map((p) => {
                    const isSelected = p.id === activeProfile.id;
                    return (
                      <button
                        key={p.id}
                        onClick={() => {
                          onSelectProfile(p.id);
                          setProfileDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 flex items-center justify-between text-xs transition ${
                          isSelected
                            ? 'bg-blue-50/80 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 font-bold'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold text-slate-700 dark:text-slate-200">
                            {p.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="truncate">{p.name}</span>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-blue-500 shrink-0" />}
                      </button>
                    );
                  })}
                </div>

                <div className="pt-1.5 mt-1 border-t border-slate-100 dark:border-slate-800 px-2 space-y-1">
                  <button
                    onClick={() => {
                      setProfileDropdownOpen(false);
                      onOpenNewProfileModal();
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Create New Profile</span>
                  </button>
                  <button
                    onClick={() => {
                      setProfileDropdownOpen(false);
                      onNavigateToSettings();
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Manage All Profiles</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* PWA Install Button */}
          <div className="hidden sm:block">
            <PWAInstallButton compact />
          </div>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-800/70 text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-700/70 active:scale-95 transition"
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle dark/light theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-blue-600" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
