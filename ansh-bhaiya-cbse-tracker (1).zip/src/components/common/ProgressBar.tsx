import React from 'react';

interface ProgressBarProps {
  percentage: number;
  height?: string;
  colorClass?: string;
  bgColorClass?: string;
  showLabel?: boolean;
  label?: string;
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  percentage,
  height = 'h-2.5',
  colorClass = 'bg-gradient-to-r from-blue-500 to-indigo-600',
  bgColorClass = 'bg-slate-200 dark:bg-slate-800',
  showLabel = false,
  label,
  className = '',
}) => {
  const clamped = Math.max(0, Math.min(100, Math.round(percentage)));

  return (
    <div className={`w-full ${className}`}>
      {showLabel && (
        <div className="flex justify-between items-center text-xs font-medium mb-1 text-slate-600 dark:text-slate-400">
          <span>{label || 'Progress'}</span>
          <span className="font-semibold text-slate-900 dark:text-slate-100">{clamped}%</span>
        </div>
      )}
      <div className={`w-full rounded-full overflow-hidden ${bgColorClass} ${height}`}>
        <div
          className={`${height} rounded-full transition-all duration-500 ease-out ${colorClass}`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
};
