import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckSquare,
  FileText,
  Plus,
  Trash2,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Search,
  BookOpen,
  Filter,
} from 'lucide-react';
import { StudyTask, Subject, Chapter } from '../../types';
import { getTodayDateString, formatDateToLocal } from '../../utils/streak';

interface NotesAndTodoViewProps {
  tasks: StudyTask[];
  subjects: Subject[];
  onAddTask: (task: Omit<StudyTask, 'id' | 'createdAt'>) => void;
  onToggleTask: (taskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onUpdateChapterNotes: (subjectId: string, chapterId: string, notes: string) => void;
}

export const NotesAndTodoView: React.FC<NotesAndTodoViewProps> = ({
  tasks,
  subjects,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onUpdateChapterNotes,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'todo' | 'notes'>('todo');
  const [filterMode, setFilterMode] = useState<'all' | 'today' | 'pending' | 'completed'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Add task form
  const [taskTitle, setTaskTitle] = useState('');
  const [taskSubject, setTaskSubject] = useState('Mathematics');
  const [taskPriority, setTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [taskDueDate, setTaskDueDate] = useState(getTodayDateString());

  // Notes search & edit
  const [notesSearch, setNotesSearch] = useState('');
  const [editingNoteChapter, setEditingNoteChapter] = useState<{
    subjectId: string;
    chapterId: string;
    chapterName: string;
    subjectName: string;
    notes: string;
  } | null>(null);

  const todayStr = getTodayDateString();

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (filterMode === 'today') return t.dueDate === todayStr;
    if (filterMode === 'pending') return !t.completed;
    if (filterMode === 'completed') return t.completed;
    return true;
  });

  // Collect all chapters with notes
  const chaptersWithNotes: Array<{
    subjectId: string;
    subjectName: string;
    chapter: Chapter;
  }> = [];

  subjects.forEach((s) => {
    s.chapters.forEach((ch) => {
      if (ch.notes && ch.notes.trim().length > 0) {
        if (
          !notesSearch ||
          ch.name.toLowerCase().includes(notesSearch.toLowerCase()) ||
          ch.notes.toLowerCase().includes(notesSearch.toLowerCase())
        ) {
          chaptersWithNotes.push({
            subjectId: s.id,
            subjectName: s.name,
            chapter: ch,
          });
        }
      }
    });
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    onAddTask({
      title: taskTitle.trim(),
      subject: taskSubject,
      priority: taskPriority,
      dueDate: taskDueDate,
      completed: false,
    });

    setTaskTitle('');
    setIsAddModalOpen(false);
  };

  const handleToggleTaskWrapper = (taskId: string, wasCompleted: boolean) => {
    if (!wasCompleted) {
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {
        // ignore
      }
    }
    onToggleTask(taskId);
  };

  const handleSaveChapterNotes = () => {
    if (!editingNoteChapter) return;
    onUpdateChapterNotes(
      editingNoteChapter.subjectId,
      editingNoteChapter.chapterId,
      editingNoteChapter.notes
    );
    setEditingNoteChapter(null);
  };

  return (
    <div className="space-y-5 pb-24 animate-in fade-in duration-300">
      {/* Tab Switcher: Tasks vs Notes */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setActiveSubTab('todo')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'todo'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Study Tasks ({tasks.filter((t) => !t.completed).length})</span>
          </button>
          <button
            onClick={() => setActiveSubTab('notes')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'notes'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Chapter Notes</span>
          </button>
        </div>

        {activeSubTab === 'todo' && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Task</span>
          </button>
        )}
      </div>

      {/* SUB-TAB 1: TO-DO TASKS */}
      {activeSubTab === 'todo' && (
        <div className="space-y-4">
          {/* Quick Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {(
              [
                { key: 'all', label: 'All Tasks' },
                { key: 'today', label: "Today's Target" },
                { key: 'pending', label: 'Pending' },
                { key: 'completed', label: 'Completed' },
              ] as const
            ).map((f) => (
              <button
                key={f.key}
                onClick={() => setFilterMode(f.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                  filterMode === f.key
                    ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Tasks List */}
          {filteredTasks.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                No study tasks found
              </h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Keep yourself accountable by planning daily chapter revisions, tests, or PYQ problem sets.
              </p>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-md shadow-indigo-600/20"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create Study Target</span>
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredTasks.map((task) => (
                <div
                  key={task.id}
                  className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                    task.completed
                      ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm hover:border-slate-300'
                  }`}
                >
                  <div
                    onClick={() => handleToggleTaskWrapper(task.id, task.completed)}
                    className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                  >
                    <div
                      className={`w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 transition-colors ${
                        task.completed
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </div>

                    <div className="min-w-0">
                      <div
                        className={`text-xs font-semibold truncate ${
                          task.completed
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {task.title}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-medium text-indigo-600 dark:text-indigo-400">
                          {task.subject}
                        </span>
                        <span>•</span>
                        <span>{formatDateToLocal(task.dueDate)}</span>
                        <span>•</span>
                        <span
                          className={`font-semibold capitalize ${
                            task.priority === 'high'
                              ? 'text-rose-500'
                              : task.priority === 'medium'
                              ? 'text-amber-500'
                              : 'text-slate-400'
                          }`}
                        >
                          {task.priority}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onDeleteTask(task.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg transition"
                    title="Delete task"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: CHAPTER NOTES */}
      {activeSubTab === 'notes' && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={notesSearch}
              onChange={(e) => setNotesSearch(e.target.value)}
              placeholder="Search in your notes and chapter formulas..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {chaptersWithNotes.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-2">
              <FileText className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                No personal chapter notes yet
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                You can write personal formula sheets, exam tips, and memory tricks on any chapter card in the Chapters section!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {chaptersWithNotes.map(({ subjectId, subjectName, chapter }) => (
                <div
                  key={chapter.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">
                        {subjectName}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {formatDateToLocal(chapter.updatedAt.split('T')[0])}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {chapter.name}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-4 font-mono bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 whitespace-pre-wrap">
                      {chapter.notes}
                    </p>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() =>
                        setEditingNoteChapter({
                          subjectId,
                          chapterId: chapter.id,
                          chapterName: chapter.name,
                          subjectName,
                          notes: chapter.notes || '',
                        })
                      }
                      className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit Notes
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add Task Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Create Study Task
            </h3>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Task Title
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  placeholder="e.g. Solve Trigonometry PYQs (2018-2023)"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Subject
                  </label>
                  <select
                    value={taskSubject}
                    onChange={(e) => setTaskSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                    <option value="General Revision">General Revision</option>
                    <option value="Mock Sample Paper">Mock Sample Paper</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={taskPriority}
                    onChange={(e) => setTaskPriority(e.target.value as 'high' | 'medium' | 'low')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="high">High Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="low">Low Priority</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  required
                  value={taskDueDate}
                  onChange={(e) => setTaskDueDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
                >
                  Add Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Notes Modal */}
      {editingNoteChapter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div>
              <div className="text-xs font-bold text-indigo-500">
                {editingNoteChapter.subjectName}
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                {editingNoteChapter.chapterName}
              </h3>
            </div>

            <textarea
              rows={8}
              value={editingNoteChapter.notes}
              onChange={(e) =>
                setEditingNoteChapter({
                  ...editingNoteChapter,
                  notes: e.target.value,
                })
              }
              placeholder="Write formulas, difficult questions, key definitions..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingNoteChapter(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveChapterNotes}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
              >
                Save Notes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
