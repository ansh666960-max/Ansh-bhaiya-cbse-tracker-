import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Edit2,
  Plus,
  Trash2,
  AlertCircle,
  CalendarCheck,
  Award,
  Sparkles,
} from 'lucide-react';
import { DatesheetItem } from '../../types';

interface DatesheetViewProps {
  datesheet: DatesheetItem[];
  onUpdateDatesheetItem: (item: DatesheetItem) => void;
  onAddDatesheetItem: (item: DatesheetItem) => void;
  onDeleteDatesheetItem: (id: string) => void;
  onResetDefaultDatesheet: () => void;
}

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
  totalMs: number;
}

function calculateTimeRemaining(dateStr: string, timeStr: string = '10:30 AM'): TimeRemaining {
  // Parse target date and time
  const target = new Date(`${dateStr}T10:30:00`);
  const now = new Date();
  const totalMs = target.getTime() - now.getTime();

  if (totalMs <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true, totalMs };
  }

  const seconds = Math.floor((totalMs / 1000) % 60);
  const minutes = Math.floor((totalMs / 1000 / 60) % 60);
  const hours = Math.floor((totalMs / (1000 * 60 * 60)) % 24);
  const days = Math.floor(totalMs / (1000 * 60 * 60 * 24));

  return { days, hours, minutes, seconds, isPast: false, totalMs };
}

export const DatesheetView: React.FC<DatesheetViewProps> = ({
  datesheet,
  onUpdateDatesheetItem,
  onAddDatesheetItem,
  onDeleteDatesheetItem,
  onResetDefaultDatesheet,
}) => {
  const [nowTick, setNowTick] = useState(Date.now());
  const [editItem, setEditItem] = useState<DatesheetItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form states
  const [formSubjectName, setFormSubjectName] = useState('');
  const [formDate, setFormDate] = useState('2027-02-17');
  const [formTime, setFormTime] = useState('10:30 AM - 01:30 PM');
  const [formCode, setFormCode] = useState('');

  // Ticking timer effect every 1 second
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTick(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const sortedDatesheet = [...datesheet].sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });

  const handleOpenEdit = (item: DatesheetItem) => {
    setEditItem(item);
    setFormSubjectName(item.subjectName);
    setFormDate(item.date);
    setFormTime(item.time);
    setFormCode(item.examCode || '');
  };

  const handleOpenAdd = () => {
    setEditItem(null);
    setFormSubjectName('');
    setFormDate('2027-02-17');
    setFormTime('10:30 AM - 01:30 PM');
    setFormCode('');
    setIsAddModalOpen(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formSubjectName.trim() || !formDate) return;

    if (editItem) {
      onUpdateDatesheetItem({
        ...editItem,
        subjectName: formSubjectName.trim(),
        date: formDate,
        time: formTime.trim() || '10:30 AM - 01:30 PM',
        examCode: formCode.trim() || undefined,
      });
      setEditItem(null);
    } else {
      onAddDatesheetItem({
        id: `exam-${Date.now().toString(36)}`,
        subjectName: formSubjectName.trim(),
        date: formDate,
        time: formTime.trim() || '10:30 AM - 01:30 PM',
        examCode: formCode.trim() || undefined,
      });
      setIsAddModalOpen(false);
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white p-5 md:p-6 shadow-xl border border-indigo-900/50">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <CalendarCheck className="w-3.5 h-3.5" /> CBSE Class 10 Datesheet
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white">
              2027 Board Exam Countdown
            </h1>
            <p className="text-xs text-slate-300">
              Official CBSE examination schedule and live real-time countdown timer.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Exam</span>
            </button>
            <button
              onClick={onResetDefaultDatesheet}
              className="px-3 py-2 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 text-xs text-slate-300 font-medium transition"
              title="Reset to official Class 10 default dates"
            >
              Reset Defaults
            </button>
          </div>
        </div>
      </div>

      {/* Examination Cards List */}
      <div className="space-y-3">
        {sortedDatesheet.map((exam) => {
          const timeLeft = calculateTimeRemaining(exam.date, exam.time);
          const examDateObj = new Date(`${exam.date}T10:30:00`);
          const formattedDate = examDateObj.toLocaleDateString('en-IN', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
          });

          return (
            <div
              key={exam.id}
              className={`p-4 md:p-5 rounded-3xl border transition-all ${
                timeLeft.isPast
                  ? 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 opacity-75'
                  : timeLeft.days <= 14
                  ? 'border-amber-500/40 bg-gradient-to-br from-amber-500/5 via-white dark:via-slate-900 to-transparent shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-base md:text-lg font-black text-slate-900 dark:text-white">
                      {exam.subjectName}
                    </span>
                    {exam.examCode && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                        Code: {exam.examCode}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                      <span>{formattedDate}</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{exam.time}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleOpenEdit(exam)}
                    className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                    title="Edit examination date or details"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteDatesheetItem(exam.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                    title="Delete examination"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Countdown Ticker Box */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                {timeLeft.isPast ? (
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                    <Award className="w-4 h-4 text-emerald-500" />
                    <span>Examination concluded</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-4 gap-2 text-center max-w-sm">
                    <div className="p-2 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40">
                      <div className="text-xl md:text-2xl font-black text-indigo-600 dark:text-indigo-400">
                        {timeLeft.days}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Days
                      </div>
                    </div>
                    <div className="p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                      <div className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-200">
                        {String(timeLeft.hours).padStart(2, '0')}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Hours
                      </div>
                    </div>
                    <div className="p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                      <div className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-200">
                        {String(timeLeft.minutes).padStart(2, '0')}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Mins
                      </div>
                    </div>
                    <div className="p-2 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                      <div className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-200">
                        {String(timeLeft.seconds).padStart(2, '0')}
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Secs
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit / Add Modal */}
      {(editItem || isAddModalOpen) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {editItem ? 'Edit Examination Date' : 'Add Board Examination'}
            </h3>

            <form onSubmit={handleSaveItem} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Subject Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mathematics, Science, Social Science"
                  value={formSubjectName}
                  onChange={(e) => setFormSubjectName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Exam Date
                </label>
                <input
                  type="date"
                  required
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Exam Timing
                </label>
                <input
                  type="text"
                  placeholder="10:30 AM - 01:30 PM"
                  value={formTime}
                  onChange={(e) => setFormTime(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Subject Code (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 041, 086, 087"
                  value={formCode}
                  onChange={(e) => setFormCode(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditItem(null);
                    setIsAddModalOpen(false);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
                >
                  {editItem ? 'Save Changes' : 'Add Examination'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
