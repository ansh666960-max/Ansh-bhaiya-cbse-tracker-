import React, { useState } from 'react';
import {
  Flame,
  Award,
  Calendar,
  CheckCircle2,
  TrendingUp,
  Sparkles,
  Info,
} from 'lucide-react';
import { Profile } from '../../types';
import {
  generateHeatmapData,
  getTodayDateString,
  formatDateToLocal,
  HeatmapDay,
} from '../../utils/streak';

interface StreakViewProps {
  profile: Profile;
  onQuickLogStreak: () => void;
}

export const StreakView: React.FC<StreakViewProps> = ({
  profile,
  onQuickLogStreak,
}) => {
  const [selectedDay, setSelectedDay] = useState<HeatmapDay | null>(null);
  const todayStr = getTodayDateString();
  const isTodayLogged = (profile.activityLog[todayStr] || 0) > 0;

  const { weeks, totalActiveDays, totalActions } = generateHeatmapData(
    profile.activityLog,
    16
  );

  const activeDatesList = Object.entries(profile.activityLog)
    .filter(([_, count]) => count > 0)
    .sort(([a], [b]) => b.localeCompare(a));

  const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-600 via-orange-600 to-amber-700 text-white p-5 md:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/20 text-white border border-white/30">
              <Flame className="w-3.5 h-3.5 fill-white" /> Study Consistency Tracker
            </div>
            <h1 className="text-xl md:text-2xl font-black text-white">
              Daily Study Streak
            </h1>
            <p className="text-xs text-amber-100">
              Every completed chapter task and study target fuels your streak.
            </p>
          </div>

          <button
            onClick={onQuickLogStreak}
            disabled={isTodayLogged}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition shadow-lg active:scale-95 ${
              isTodayLogged
                ? 'bg-white/20 text-white cursor-not-allowed border border-white/30'
                : 'bg-white text-orange-600 hover:bg-amber-50 shadow-black/10'
            }`}
          >
            {isTodayLogged ? '✅ Active Today' : '+ Log Study Session'}
          </button>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
            <Flame className="w-7 h-7 fill-amber-500 text-amber-500" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {profile.currentStreak} <span className="text-sm font-semibold text-slate-400">Days</span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Current Active Streak</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center shrink-0">
            <Award className="w-7 h-7 text-indigo-500" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {profile.longestStreak} <span className="text-sm font-semibold text-slate-400">Days</span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Longest Streak Record</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
            <TrendingUp className="w-7 h-7 text-emerald-500" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {totalActiveDays} <span className="text-sm font-semibold text-slate-400">Days</span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Total Study Days Logged</div>
          </div>
        </div>
      </div>

      {/* Calendar Heatmap Section */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Activity Heatmap
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Past 16 weeks of study consistency
            </p>
          </div>
          <div className="text-xs text-slate-500 font-semibold">
            {totalActions} activities completed
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="overflow-x-auto pb-2">
          <div className="min-w-[480px]">
            <div className="flex gap-1.5">
              {/* Day of week labels */}
              <div className="flex flex-col gap-1.5 pr-2 justify-between text-[9px] font-bold text-slate-400 select-none py-0.5">
                <span>Sun</span>
                <span>Tue</span>
                <span>Thu</span>
                <span>Sat</span>
              </div>

              {/* Weeks columns */}
              <div className="flex gap-1.5 flex-1">
                {weeks.map((week, wIdx) => (
                  <div key={wIdx} className="flex flex-col gap-1.5 flex-1">
                    {week.map((day) => {
                      const isSelected = selectedDay?.date === day.date;
                      return (
                        <div
                          key={day.date}
                          onClick={() => setSelectedDay(day)}
                          title={`${formatDateToLocal(day.date)}: ${day.count} activities`}
                          className={`w-full aspect-square rounded-md cursor-pointer transition-transform hover:scale-125 ${
                            day.isToday ? 'ring-2 ring-indigo-500 ring-offset-1 dark:ring-offset-slate-900' : ''
                          } ${
                            isSelected ? 'scale-125 z-10' : ''
                          } ${
                            day.level === 4
                              ? 'bg-emerald-600 dark:bg-emerald-500'
                              : day.level === 3
                              ? 'bg-emerald-500/80 dark:bg-emerald-500/80'
                              : day.level === 2
                              ? 'bg-emerald-400/60 dark:bg-emerald-600/50'
                              : day.level === 1
                              ? 'bg-emerald-300/40 dark:bg-emerald-800/40'
                              : 'bg-slate-100 dark:bg-slate-800'
                          }`}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            {/* Heatmap Legend */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-4 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="flex items-center gap-1">
                <Info className="w-3 h-3" /> Tap any cell to view date details
              </span>
              <div className="flex items-center gap-1.5 font-medium">
                <span>Less</span>
                <span className="w-3 h-3 rounded bg-slate-100 dark:bg-slate-800" />
                <span className="w-3 h-3 rounded bg-emerald-300/40 dark:bg-emerald-800/40" />
                <span className="w-3 h-3 rounded bg-emerald-400/60 dark:bg-emerald-600/50" />
                <span className="w-3 h-3 rounded bg-emerald-500/80 dark:bg-emerald-500/80" />
                <span className="w-3 h-3 rounded bg-emerald-600 dark:bg-emerald-500" />
                <span>More</span>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Day Details Preview */}
        {selectedDay && (
          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {formatDateToLocal(selectedDay.date)}
                </span>
                {selectedDay.isToday && (
                  <span className="ml-2 text-[10px] font-bold text-indigo-500 uppercase">
                    (Today)
                  </span>
                )}
              </div>
            </div>
            <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              {selectedDay.count} study actions logged
            </div>
          </div>
        )}
      </div>

      {/* Activity Log History */}
      <div className="space-y-3">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          Recent Study Activity Log
        </h3>

        {activeDatesList.length === 0 ? (
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
            No study activity logged yet. Complete any task in Chapters or Tasks to start recording your streak!
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {activeDatesList.map(([dateStr, count]) => (
              <div
                key={dateStr}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {formatDateToLocal(dateStr)}
                  </span>
                  {dateStr === todayStr && (
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-indigo-500/10 text-indigo-500">
                      Today
                    </span>
                  )}
                </div>
                <span className="font-bold text-indigo-600 dark:text-indigo-400">
                  {count} activities
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
