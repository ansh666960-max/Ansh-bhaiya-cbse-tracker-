import React from 'react';
import {
  Flame,
  Calendar,
  CheckCircle2,
  Clock,
  BookOpen,
  ArrowRight,
  Sparkles,
  Trophy,
  Target,
  Plus,
  Compass,
  Timer,
} from 'lucide-react';
import { Profile, NavTab, Subject } from '../../types';
import { getOverallProgress, getSubjectProgress } from '../../utils/progress';
import { ProgressRing } from '../common/ProgressRing';
import { ProgressBar } from '../common/ProgressBar';
import { PWAInstallButton } from '../common/PWAInstallButton';
import { getTodayDateString, formatDateToLocal } from '../../utils/streak';

interface DashboardViewProps {
  profile: Profile;
  onNavigateTab: (tab: NavTab) => void;
  onSelectSubject: (subjectId: string) => void;
  onLoadOfficialSyllabus: () => void;
  onQuickLogStreak: () => void;
  onToggleTaskComplete: (taskId: string) => void;
  onOpenAddTaskModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  onNavigateTab,
  onSelectSubject,
  onLoadOfficialSyllabus,
  onQuickLogStreak,
  onToggleTaskComplete,
  onOpenAddTaskModal,
}) => {
  const overall = getOverallProgress(profile.subjects);
  const todayStr = getTodayDateString();

  // Filter today's tasks
  const todayTasks = profile.studyTasks.filter(
    (t) => t.dueDate === todayStr || (!t.completed && t.dueDate <= todayStr)
  );

  // Next upcoming board examination countdown
  const now = new Date();
  const upcomingExams = [...profile.datesheet]
    .map((exam) => {
      const examDate = new Date(`${exam.date}T10:30:00`);
      const diffMs = examDate.getTime() - now.getTime();
      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      return { ...exam, diffDays };
    })
    .sort((a, b) => {
      // Show future exams first, closest first
      if (a.diffDays >= 0 && b.diffDays >= 0) return a.diffDays - b.diffDays;
      if (a.diffDays >= 0) return -1;
      if (b.diffDays >= 0) return 1;
      return b.diffDays - a.diffDays;
    });

  const nextExam = upcomingExams.find((e) => e.diffDays >= 0);

  const isTodayLogged = (profile.activityLog[todayStr] || 0) > 0;

  const todayFocusMinutes = (profile.studySessions || [])
    .filter((s) => s.completedAt.startsWith(todayStr))
    .reduce((sum, s) => sum + s.durationMinutes, 0);

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Welcome & Goal Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-5 md:p-6 shadow-xl border border-indigo-900/50">
        <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />
        <div className="absolute right-12 top-2 w-32 h-32 rounded-full bg-sky-500/10 blur-xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <Sparkles className="w-3 h-3 text-amber-300" /> CBSE Class 10 • 2027 Boards
            </div>
            <h1 className="text-xl md:text-2xl font-black tracking-tight text-white">
              Hello, {profile.name}! 👋
            </h1>
            <p className="text-xs md:text-sm text-slate-300">
              Target: <strong className="text-amber-300">{profile.targetScore}%+</strong> in Board Examinations
            </p>
          </div>

          {/* Master Progress Ring */}
          <div className="flex items-center gap-4 self-center md:self-auto bg-white/5 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10">
            <ProgressRing
              percentage={overall.overallPercentage}
              size={84}
              strokeWidth={8}
              colorStart="#38bdf8"
              colorEnd="#818cf8"
            >
              <span className="text-lg font-black text-white">{overall.overallPercentage}%</span>
              <span className="text-[9px] uppercase tracking-wider text-slate-300 font-semibold">Done</span>
            </ProgressRing>
            <div>
              <div className="text-xs text-slate-400 font-medium">Syllabus Complete</div>
              <div className="text-base font-bold text-white">
                {overall.completedChapters} / {overall.totalChapters} Chapters
              </div>
              <div className="text-[11px] text-indigo-300 font-medium">
                {overall.totalTasksCompleted} tasks mastered
              </div>
            </div>
          </div>
        </div>

        {/* In-app install banner if mobile prompt is available */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between sm:hidden">
          <span className="text-xs text-slate-300">Install app for fast offline access</span>
          <PWAInstallButton compact />
        </div>
      </div>

      {/* Empty Tracker Call to Action if 0 chapters */}
      {overall.totalChapters === 0 && (
        <div className="rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/50 dark:bg-indigo-950/20 p-5 text-center space-y-3">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md">
            <Compass className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Your tracker is currently empty
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto mt-1">
              Start by loading the official CBSE Class 10 NCERT syllabus (Science, Maths, SST, English, Hindi) or add your custom chapters anytime.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              onClick={onLoadOfficialSyllabus}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 active:scale-95 transition"
            >
              <BookOpen className="w-4 h-4" />
              <span>Load Official CBSE 10th Syllabus (0% Clean)</span>
            </button>
            <button
              onClick={() => onNavigateTab('chapters')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-700 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Chapter</span>
            </button>
          </div>
        </div>
      )}

      {/* 4 Quick Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold">Total Chapters</span>
            <BookOpen className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {overall.totalChapters}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Across 5 subjects</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
            <span className="text-xs font-semibold">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {overall.completedChapters}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">All 7 tasks finished</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-600 dark:text-amber-400">
            <span className="text-xs font-semibold">In Progress</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-amber-600 dark:text-amber-400">
              {overall.inProgressChapters}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Under active study</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold">Pending</span>
            <Target className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-black text-slate-700 dark:text-slate-300">
              {overall.pendingChapters}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Yet to start</div>
          </div>
        </div>
      </div>

      {/* Highlights Grid: Streak, Focus Timer, Next Exam */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Study Streak Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/20 dark:border-amber-500/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-500 flex items-center justify-center font-bold">
                  <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Study Streak</h3>
                  <p className="text-[10px] text-slate-400">Daily consistency</p>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('streak')}
                className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
              >
                Heatmap →
              </button>
            </div>

            <div className="my-2.5">
              <span className="text-2xl font-black text-slate-900 dark:text-white">
                {profile.currentStreak}{' '}
                <span className="text-xs font-semibold text-slate-400">days</span>
              </span>
              <div className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-0.5">
                Record: {profile.longestStreak} days
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-amber-500/10 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              {isTodayLogged ? '✅ Active today' : 'No study yet'}
            </span>
            <button
              onClick={onQuickLogStreak}
              disabled={isTodayLogged}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                isTodayLogged
                  ? 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                  : 'bg-amber-500 text-white hover:bg-amber-600'
              }`}
            >
              {isTodayLogged ? 'Logged' : '+ Log'}
            </button>
          </div>
        </div>

        {/* Focus Study Timer Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 via-cyan-500/5 to-transparent border border-blue-500/20 dark:border-blue-500/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center font-bold">
                  <Timer className="w-4 h-4 text-blue-500" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Focus Tools</h3>
                  <p className="text-[10px] text-slate-400">Timer & Stopwatch</p>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('focus')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Start →
              </button>
            </div>

            <div className="my-2.5">
              <span className="text-2xl font-black text-slate-900 dark:text-white">
                {Math.floor(todayFocusMinutes / 60)}h {todayFocusMinutes % 60}m
              </span>
              <div className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold mt-0.5">
                {(profile.studySessions || []).filter((s) => s.completedAt.startsWith(todayStr)).length} focus session(s) today
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-blue-500/10 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">25m • 45m • 60m</span>
            <button
              onClick={() => onNavigateTab('focus')}
              className="px-2.5 py-1 rounded-lg bg-blue-600 text-white text-xs font-bold hover:bg-blue-500 transition shadow-sm"
            >
              Open Timer
            </button>
          </div>
        </div>

        {/* Next Exam Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent border border-indigo-500/20 dark:border-indigo-500/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center font-bold">
                  <Calendar className="w-4 h-4 text-indigo-500" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Next Exam</h3>
                  <p className="text-[10px] text-slate-400">Class 10 2027</p>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('datesheet')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Schedule →
              </button>
            </div>

            <div className="my-2.5 truncate">
              {nextExam ? (
                <>
                  <div className="text-base font-black text-slate-900 dark:text-white truncate">
                    {nextExam.subjectName}
                  </div>
                  <div className="text-xl font-black text-indigo-600 dark:text-indigo-400 mt-0.5">
                    {nextExam.diffDays}{' '}
                    <span className="text-xs font-semibold text-slate-400">days left</span>
                  </div>
                </>
              ) : (
                <div className="text-xs text-slate-400 py-1">No upcoming exams</div>
              )}
            </div>
          </div>

          <div className="pt-2 border-t border-indigo-500/10 flex items-center justify-between text-[11px] text-slate-500">
            <span className="truncate">
              {nextExam ? formatDateToLocal(nextExam.date) : '2027 Boards'}
            </span>
            <span className="font-bold text-indigo-600 dark:text-indigo-400">CBSE</span>
          </div>
        </div>
      </div>

      {/* Subject-Wise Progress Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Subject Progress
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              5 core subjects for Class 10
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('chapters')}
            className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            All Chapters <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {profile.subjects.map((subject: Subject) => {
            const subProg = getSubjectProgress(subject);
            return (
              <div
                key={subject.id}
                onClick={() => {
                  onSelectSubject(subject.id);
                  onNavigateTab('chapters');
                }}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-indigo-400/50 dark:hover:border-indigo-500/50 transition cursor-pointer active:scale-[0.99] group"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${subject.color} flex items-center justify-center text-white font-bold text-xs shadow-sm`}
                    >
                      {subject.name.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {subject.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {subProg.totalChapters} chapters
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-slate-900 dark:text-white">
                      {subProg.percentage}%
                    </span>
                  </div>
                </div>

                <ProgressBar
                  percentage={subProg.percentage}
                  height="h-2"
                  colorClass={`bg-gradient-to-r ${subject.color}`}
                />

                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2.5">
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                    {subProg.completedChapters} done
                  </span>
                  <span>{subProg.inProgressChapters} in progress</span>
                  <span>{subProg.pendingChapters} pending</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Today's Study Targets / Quick Tasks */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Today's Study Targets
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Complete tasks to advance your study streak
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAddTaskModal}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Target</span>
            </button>
            <button
              onClick={() => onNavigateTab('tasks')}
              className="text-xs font-semibold text-slate-500 dark:text-slate-400 hover:underline"
            >
              View All
            </button>
          </div>
        </div>

        {todayTasks.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 text-center">
            <CheckCircle2 className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-xs text-slate-600 dark:text-slate-400">
              No pending study targets for today.
            </p>
            <button
              onClick={onOpenAddTaskModal}
              className="mt-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              + Create a target for today
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {todayTasks.slice(0, 4).map((task) => (
              <div
                key={task.id}
                onClick={() => onToggleTaskComplete(task.id)}
                className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition active:scale-[0.99] ${
                  task.completed
                    ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                      task.completed
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-slate-300 dark:border-slate-600'
                    }`}
                  >
                    {task.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                  <div>
                    <div
                      className={`text-xs font-semibold ${
                        task.completed
                          ? 'line-through text-slate-400 dark:text-slate-500'
                          : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      {task.title}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500">
                      <span>{task.subject}</span>
                      <span>•</span>
                      <span
                        className={`capitalize font-semibold ${
                          task.priority === 'high'
                            ? 'text-rose-500'
                            : task.priority === 'medium'
                            ? 'text-amber-500'
                            : 'text-slate-400'
                        }`}
                      >
                        {task.priority} Priority
                      </span>
                    </div>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    task.completed
                      ? 'bg-emerald-500/10 text-emerald-500'
                      : 'bg-indigo-500/10 text-indigo-500'
                  }`}
                >
                  {task.completed ? 'Done' : 'Tap to Complete'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
