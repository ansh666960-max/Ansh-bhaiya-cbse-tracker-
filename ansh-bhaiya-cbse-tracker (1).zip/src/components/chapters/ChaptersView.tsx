import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Clock,
  Circle,
  FileText,
  BookOpen,
  Sparkles,
  DownloadCloud,
} from 'lucide-react';
import {
  Chapter,
  Subject,
  TaskKey,
  TaskState,
  TASK_DEFINITIONS,
  SubjectId,
} from '../../types';
import { getChapterProgress, getSubjectProgress } from '../../utils/progress';
import { ProgressBar } from '../common/ProgressBar';

interface ChaptersViewProps {
  subjects: Subject[];
  selectedSubjectId: string;
  onSelectSubjectId: (id: string) => void;
  onUpdateTaskState: (subjectId: string, chapterId: string, taskKey: TaskKey, newState: TaskState) => void;
  onAddChapter: (subjectId: string, chapterName: string) => void;
  onEditChapter: (subjectId: string, chapterId: string, newName: string) => void;
  onDeleteChapter: (subjectId: string, chapterId: string) => void;
  onUpdateChapterNotes: (subjectId: string, chapterId: string, notes: string) => void;
  onLoadOfficialSubjectChapters: (subjectId: string) => void;
  isAdmin?: boolean;
  onOpenAdminCenter?: () => void;
  onBatchSetChapterTasks?: (subjectId: string, chapterId: string, state: TaskState) => void;
}

export const ChaptersView: React.FC<ChaptersViewProps> = ({
  subjects,
  selectedSubjectId,
  onSelectSubjectId,
  onUpdateTaskState,
  onAddChapter,
  onEditChapter,
  onDeleteChapter,
  onUpdateChapterNotes,
  onLoadOfficialSubjectChapters,
  isAdmin = false,
  onOpenAdminCenter,
  onBatchSetChapterTasks,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'in_progress' | 'not_started'>('all');
  const [expandedChapterIds, setExpandedChapterIds] = useState<Record<string, boolean>>({});

  // Modals state
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newChapterName, setNewChapterName] = useState('');
  const [targetSubjectIdForAdd, setTargetSubjectIdForAdd] = useState(selectedSubjectId);

  const [editModalChapter, setEditModalChapter] = useState<{ subjectId: string; chapter: Chapter } | null>(null);
  const [editedName, setEditedName] = useState('');

  const [deleteConfirmChapter, setDeleteConfirmChapter] = useState<{ subjectId: string; chapter: Chapter } | null>(null);

  const [notesDrawerChapter, setNotesDrawerChapter] = useState<{ subjectId: string; chapter: Chapter } | null>(null);
  const [currentNotes, setCurrentNotes] = useState('');

  // Find active subject
  const currentSubject = subjects.find((s) => s.id === selectedSubjectId) || subjects[0];
  const subjectProgress = currentSubject ? getSubjectProgress(currentSubject) : null;

  // Toggle chapter accordion expansion
  const toggleExpand = (chId: string) => {
    setExpandedChapterIds((prev) => ({
      ...prev,
      [chId]: !prev[chId],
    }));
  };

  // Filtered chapters for active subject
  const filteredChapters = useMemo(() => {
    if (!currentSubject) return [];
    return currentSubject.chapters.filter((ch) => {
      // Search filter
      const matchesSearch = ch.name.toLowerCase().includes(searchQuery.toLowerCase().trim());
      if (!matchesSearch) return false;

      // Status filter
      if (statusFilter === 'all') return true;
      const prog = getChapterProgress(ch);
      return prog.status === statusFilter;
    });
  }, [currentSubject, searchQuery, statusFilter]);

  // Handle task click: cycles Not Started -> In Progress -> Completed -> Not Started
  const handleTaskCycle = (ch: Chapter, taskKey: TaskKey) => {
    const current = ch.tasks[taskKey] || 'not_started';
    let next: TaskState = 'in_progress';
    if (current === 'not_started') next = 'in_progress';
    else if (current === 'in_progress') next = 'completed';
    else next = 'not_started';

    onUpdateTaskState(currentSubject.id, ch.id, taskKey, next);

    // If this action makes all 7 tasks completed, fire confetti celebration!
    if (next === 'completed') {
      const willBeCompleted = TASK_DEFINITIONS.every((t) => {
        if (t.key === taskKey) return true;
        return ch.tasks[t.key] === 'completed';
      });

      if (willBeCompleted) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {
          // ignore
        }
      }
    }
  };

  const handleOpenAddModal = (subjId?: string) => {
    setTargetSubjectIdForAdd(subjId || currentSubject.id);
    setNewChapterName('');
    setAddModalOpen(true);
  };

  const handleSaveNewChapter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChapterName.trim()) return;
    onAddChapter(targetSubjectIdForAdd, newChapterName.trim());
    setAddModalOpen(false);
    setNewChapterName('');
  };

  const handleOpenEditModal = (chapter: Chapter) => {
    setEditModalChapter({ subjectId: currentSubject.id, chapter });
    setEditedName(chapter.name);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModalChapter || !editedName.trim()) return;
    onEditChapter(editModalChapter.subjectId, editModalChapter.chapter.id, editedName.trim());
    setEditModalChapter(null);
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirmChapter) return;
    onDeleteChapter(deleteConfirmChapter.subjectId, deleteConfirmChapter.chapter.id);
    setDeleteConfirmChapter(null);
  };

  const handleOpenNotes = (chapter: Chapter) => {
    setNotesDrawerChapter({ subjectId: currentSubject.id, chapter });
    setCurrentNotes(chapter.notes || '');
  };

  const handleSaveNotes = () => {
    if (!notesDrawerChapter) return;
    onUpdateChapterNotes(notesDrawerChapter.subjectId, notesDrawerChapter.chapter.id, currentNotes);
    setNotesDrawerChapter(null);
  };

  return (
    <div className="space-y-5 pb-24 animate-in fade-in duration-300">
      {/* Subject Filter Tabs Bar */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {subjects.map((sub) => {
          const isSelected = sub.id === selectedSubjectId;
          const prog = getSubjectProgress(sub);

          return (
            <button
              key={sub.id}
              onClick={() => onSelectSubjectId(sub.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl whitespace-nowrap text-xs font-bold transition-all active:scale-95 shrink-0 ${
                isSelected
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-md'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-2.5 h-2.5 rounded-full ${
                  isSelected ? 'bg-indigo-400' : 'bg-slate-300 dark:bg-slate-600'
                }`}
              />
              <span>{sub.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
                  isSelected
                    ? 'bg-white/20 text-white dark:bg-slate-900/20 dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {prog.percentage}%
              </span>
            </button>
          );
        })}

        {isAdmin && onOpenAdminCenter && (
          <button
            onClick={onOpenAdminCenter}
            className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-dashed border-amber-500/40 text-xs font-bold shrink-0 transition"
            title="Admin: Add / Manage Custom Subjects"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Subject</span>
          </button>
        )}
      </div>

      {/* Active Subject Overview Header */}
      {currentSubject && subjectProgress && (
        <div className="p-4 md:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${currentSubject.color} flex items-center justify-center text-white font-extrabold text-base shadow-md`}
              >
                {currentSubject.name.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <h1 className="text-lg md:text-xl font-black text-slate-900 dark:text-white">
                  {currentSubject.name}
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {subjectProgress.totalChapters} Chapters • {subjectProgress.completedChapters} Completed
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isAdmin && onOpenAdminCenter && (
                <button
                  onClick={onOpenAdminCenter}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-bold hover:bg-amber-500/20 transition"
                  title="Admin Controls"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Admin Edit</span>
                </button>
              )}

              <button
                onClick={() => handleOpenAddModal(currentSubject.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm shadow-indigo-600/30 transition active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Chapter</span>
              </button>

              {currentSubject.chapters.length === 0 && (
                <button
                  onClick={() => onLoadOfficialSubjectChapters(currentSubject.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 transition"
                  title="Load official Class 10 NCERT chapters for this subject"
                >
                  <DownloadCloud className="w-3.5 h-3.5" />
                  <span>Load NCERT Chapters</span>
                </button>
              )}
            </div>
          </div>

          <ProgressBar
            percentage={subjectProgress.percentage}
            height="h-2.5"
            colorClass={`bg-gradient-to-r ${currentSubject.color}`}
            showLabel
            label="Subject Completion"
          />
        </div>
      )}

      {/* Search & Status Filter Controls */}
      <div className="flex flex-col sm:flex-row gap-2">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search chapters in this subject..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
            >
              Clear
            </button>
          )}
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
          {(
            [
              { key: 'all', label: 'All' },
              { key: 'completed', label: 'Done' },
              { key: 'in_progress', label: 'Active' },
              { key: 'not_started', label: 'Pending' },
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              onClick={() => setStatusFilter(item.key)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                statusFilter === item.key
                  ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chapters List */}
      {filteredChapters.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center space-y-3">
          <BookOpen className="w-10 h-10 text-slate-400 mx-auto" />
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              No chapters found
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto mt-1">
              {currentSubject?.chapters.length === 0
                ? 'No chapters added to this subject yet.'
                : 'No chapters match your search filter.'}
            </p>
          </div>

          {currentSubject?.chapters.length === 0 && (
            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              <button
                onClick={() => onLoadOfficialSubjectChapters(currentSubject.id)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-md shadow-indigo-600/20 hover:bg-indigo-500 transition"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>Load Official NCERT Chapters</span>
              </button>
              <button
                onClick={() => handleOpenAddModal()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Chapter</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredChapters.map((chapter: Chapter, index: number) => {
            const prog = getChapterProgress(chapter);
            const isExpanded = Boolean(expandedChapterIds[chapter.id]);

            return (
              <div
                key={chapter.id}
                className={`rounded-2xl border transition-all ${
                  prog.status === 'completed'
                    ? 'border-emerald-500/30 bg-emerald-500/5 dark:bg-emerald-950/10'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                } shadow-sm overflow-hidden`}
              >
                {/* Chapter Card Header / Summary */}
                <div
                  onClick={() => toggleExpand(chapter.id)}
                  className="p-4 cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition select-none flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Chapter index badge or completed tick */}
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                        prog.status === 'completed'
                          ? 'bg-emerald-500 text-white'
                          : prog.status === 'in_progress'
                          ? 'bg-amber-500/10 text-amber-500 border border-amber-500/30'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}
                    >
                      {prog.status === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        index + 1
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {chapter.name}
                        </h3>
                        {chapter.notes && (
                          <span
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenNotes(chapter);
                            }}
                            className="p-1 text-indigo-500 hover:text-indigo-600 rounded"
                            title="Has chapter notes"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          {prog.completedCount} / 7 tasks done
                        </span>
                        <span>•</span>
                        <span
                          className={`font-semibold capitalize ${
                            prog.status === 'completed'
                              ? 'text-emerald-500'
                              : prog.status === 'in_progress'
                              ? 'text-amber-500'
                              : 'text-slate-400'
                          }`}
                        >
                          {prog.status === 'in_progress' ? 'In Progress' : prog.status}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right">
                      <span className="text-sm font-black text-slate-900 dark:text-white">
                        {prog.percentage}%
                      </span>
                    </div>

                    <button
                      type="button"
                      className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Progress Line */}
                <div className="px-4 pb-2">
                  <ProgressBar
                    percentage={prog.percentage}
                    height="h-1.5"
                    colorClass={
                      prog.status === 'completed'
                        ? 'bg-emerald-500'
                        : 'bg-gradient-to-r from-blue-500 to-indigo-600'
                    }
                  />
                </div>

                {/* Expanded Card Body: 7 Tasks + Actions */}
                {isExpanded && (
                  <div className="p-4 pt-2 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/20 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-bold uppercase tracking-wider text-[10px]">
                        CBSE 7-Task Checklist (Tap to toggle)
                      </span>
                      <div className="flex items-center gap-2">
                        {isAdmin && onBatchSetChapterTasks && (
                          <div className="flex items-center gap-1 mr-1">
                            <button
                              type="button"
                              onClick={() => onBatchSetChapterTasks(currentSubject.id, chapter.id, 'completed')}
                              className="px-2 py-0.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold transition active:scale-95"
                              title="Admin: Mark all 7 tasks complete"
                            >
                              All Done
                            </button>
                            <button
                              type="button"
                              onClick={() => onBatchSetChapterTasks(currentSubject.id, chapter.id, 'not_started')}
                              className="px-2 py-0.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 text-[10px] font-semibold transition active:scale-95"
                              title="Admin: Reset all tasks"
                            >
                              Reset
                            </button>
                          </div>
                        )}
                        <button
                          onClick={() => handleOpenNotes(chapter)}
                          className="flex items-center gap-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          <FileText className="w-3 h-3" />
                          <span>Notes</span>
                        </button>
                        <button
                          onClick={() => handleOpenEditModal(chapter)}
                          className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                          title="Rename chapter"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmChapter({ subjectId: currentSubject.id, chapter })}
                          className="p-1 text-rose-400 hover:text-rose-600"
                          title="Delete chapter"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* 7 Task Interactive Pills / Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {TASK_DEFINITIONS.map((def) => {
                        const state = chapter.tasks[def.key] || 'not_started';

                        return (
                          <div
                            key={def.key}
                            onClick={() => handleTaskCycle(chapter, def.key)}
                            className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition select-none active:scale-[0.98] ${
                              state === 'completed'
                                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                                : state === 'in_progress'
                                ? 'bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-300'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              {state === 'completed' ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                              ) : state === 'in_progress' ? (
                                <Clock className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
                              ) : (
                                <Circle className="w-4 h-4 text-slate-300 dark:text-slate-600 shrink-0" />
                              )}
                              <div className="min-w-0">
                                <div className="text-xs font-bold truncate">
                                  {def.label}
                                </div>
                                <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate">
                                  {def.description}
                                </div>
                              </div>
                            </div>

                            <span
                              className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full shrink-0 ${
                                state === 'completed'
                                  ? 'bg-emerald-500 text-white'
                                  : state === 'in_progress'
                                  ? 'bg-amber-500 text-white'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                              }`}
                            >
                              {state === 'in_progress'
                                ? 'In Progress'
                                : state === 'completed'
                                ? 'Done'
                                : 'Not Started'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add Chapter Modal */}
      {addModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              Add New Chapter
            </h3>
            <form onSubmit={handleSaveNewChapter} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Target Subject
                </label>
                <select
                  value={targetSubjectIdForAdd}
                  onChange={(e) => setTargetSubjectIdForAdd(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-900 dark:text-white"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Chapter Name
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  placeholder="e.g. Carbon and its Compounds"
                  value={newChapterName}
                  onChange={(e) => setNewChapterName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
                >
                  Create Chapter
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Chapter Modal */}
      {editModalChapter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              Edit Chapter Name
            </h3>
            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Chapter Name
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditModalChapter(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmChapter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Delete Chapter?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Are you sure you want to delete <strong className="text-slate-900 dark:text-white">"{deleteConfirmChapter.chapter.name}"</strong>? All 7 task records and personal notes for this chapter will be permanently removed.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmChapter(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Keep Chapter
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-600/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chapter Notes Drawer Modal */}
      {notesDrawerChapter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                  Notes: {notesDrawerChapter.chapter.name}
                </h3>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Personal formulas, key takeaways & revision points
              </label>
              <textarea
                rows={7}
                value={currentNotes}
                onChange={(e) => setCurrentNotes(e.target.value)}
                placeholder="Write your personal chapter summary, formulas, difficult questions, or reminders..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-mono"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setNotesDrawerChapter(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNotes}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
              >
                Save Notes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
