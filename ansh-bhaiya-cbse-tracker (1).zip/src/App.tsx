import React, { useState, useEffect, useCallback } from 'react';
import {
  AppState,
  Profile,
  NavTab,
  TaskKey,
  TaskState,
  StudyTask,
  DatesheetItem,
  BackupSnapshot,
  AuthUser,
  StudySession,
  Subject,
  isUserAdmin,
} from './types';
import {
  loadAppState,
  saveAppState,
  createAutomaticBackup,
  getBackupSnapshots,
  createDefaultProfile,
  createInitialAppState,
} from './utils/storage';
import { recordStudyActivity } from './utils/streak';
import {
  createOfficialChaptersForSubject,
  DEFAULT_DATESHEET,
} from './data/defaultCurriculum';
import { getStoredLocalUser, getSupabaseClient } from './utils/supabase';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { DashboardView } from './components/dashboard/DashboardView';
import { ChaptersView } from './components/chapters/ChaptersView';
import { FocusToolsView } from './components/focus/FocusToolsView';
import { DatesheetView } from './components/datesheet/DatesheetView';
import { StreakView } from './components/streak/StreakView';
import { NotesAndTodoView } from './components/tasks/NotesAndTodoView';
import { SettingsView } from './components/settings/SettingsView';
import { AuthModal } from './components/auth/AuthModal';
import { AdminControlCenter } from './components/admin/AdminControlCenter';

export default function App() {
  const [appState, setAppState] = useState<AppState | null>(null);
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('science');
  const [backups, setBackups] = useState<BackupSnapshot[]>([]);
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(getStoredLocalUser());
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [adminCenterOpen, setAdminCenterOpen] = useState(false);
  const [isNewProfileModalOpen, setIsNewProfileModalOpen] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileTarget, setNewProfileTarget] = useState(95);

  // Initialize and load from IndexedDB on startup
  useEffect(() => {
    async function init() {
      const user = getStoredLocalUser();
      setCurrentUser(user);

      // Check if Supabase session is active
      const supabase = getSupabaseClient();
      if (supabase) {
        try {
          const { data } = await supabase.auth.getSession();
          if (data.session?.user) {
            const authUser: AuthUser = {
              id: data.session.user.id,
              email: data.session.user.email || '',
              name: data.session.user.user_metadata?.full_name || data.session.user.email?.split('@')[0] || 'Student',
              createdAt: data.session.user.created_at || new Date().toISOString(),
            };
            setCurrentUser(authUser);
          }
        } catch {
          // offline mode
        }
      }

      const state = await loadAppState(user?.id);
      setAppState(state);

      // Apply theme to DOM documentElement
      if (state.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }

      // Load backup snapshots
      const snaps = await getBackupSnapshots();
      setBackups(snaps);
    }
    init();
  }, []);

  // Update theme helper
  const handleToggleTheme = () => {
    if (!appState) return;
    const nextTheme = appState.theme === 'dark' ? 'light' : 'dark';
    const updated: AppState = { ...appState, theme: nextTheme };
    setAppState(updated);
    saveAppState(updated);

    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Helper to commit state updates to IndexedDB and state
  const commitState = useCallback((newState: AppState, createBackup = false) => {
    setAppState(newState);
    saveAppState(newState);
    if (createBackup) {
      createAutomaticBackup(newState).then(() => {
        getBackupSnapshots().then(setBackups);
      });
    }
  }, []);

  // Handle Authentication Success (User signs in / registers)
  const handleAuthSuccess = async (user: AuthUser) => {
    setCurrentUser(user);
    // Load isolated data for this user
    const userState = await loadAppState(user.id);
    commitState(userState);
  };

  // Handle Logout
  const handleLogoutSuccess = async () => {
    setCurrentUser(null);
    // Reload guest/offline tracker data
    const guestState = await loadAppState();
    commitState(guestState);
  };

  // Splash Screen / Initial Loading with Official Logo
  if (!appState) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white p-4">
        <div className="flex flex-col items-center text-center max-w-xs space-y-4 animate-in fade-in zoom-in duration-500">
          <div className="relative">
            <div className="w-24 h-24 rounded-full overflow-hidden shadow-2xl ring-4 ring-blue-500/30 bg-slate-900 animate-pulse">
              <img
                src="/logo.png"
                alt="Ansh Bhaiya CBSE Tracker"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg text-[10px] font-black">
              10
            </div>
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white">
              Ansh Bhaiya CBSE Tracker
            </h1>
            <p className="text-xs text-blue-400 font-semibold mt-0.5">
              Class 10 Board 2027 • Offline First
            </p>
          </div>
          <div className="w-36 h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 rounded-full animate-indeterminate" />
          </div>
        </div>
      </div>
    );
  }

  // Active Profile
  const activeProfile =
    appState.profiles.find((p) => p.id === appState.activeProfileId) ||
    appState.profiles[0];

  // Helper to update active profile cleanly
  const updateActiveProfile = (updater: (prev: Profile) => Profile, triggerAutoBackup = false) => {
    const updatedProf = updater(activeProfile);
    const updatedProfiles = appState.profiles.map((p) =>
      p.id === activeProfile.id ? updatedProf : p
    );
    const nextState: AppState = {
      ...appState,
      profiles: updatedProfiles,
    };
    commitState(nextState, triggerAutoBackup);
  };

  // 1. Task State Update in a Chapter
  const handleUpdateTaskState = (
    subjectId: string,
    chapterId: string,
    taskKey: TaskKey,
    newState: TaskState
  ) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        const updatedChapters = sub.chapters.map((ch) => {
          if (ch.id !== chapterId) return ch;
          return {
            ...ch,
            tasks: {
              ...ch.tasks,
              [taskKey]: newState,
            },
            updatedAt: now,
          };
        });
        return { ...sub, chapters: updatedChapters };
      });

      // Record study activity streak if task is in_progress or completed
      let updatedProf: Profile = { ...prof, subjects: updatedSubjects };
      if (newState === 'completed' || newState === 'in_progress') {
        updatedProf = recordStudyActivity(updatedProf, 1);
      }

      return updatedProf;
    }, true);
  };

  // 2. Add Custom Chapter
  const handleAddChapter = (subjectId: string, chapterName: string) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const newCh = {
        id: `${subjectId}-custom-${Date.now().toString(36)}`,
        name: chapterName,
        subjectId,
        tasks: {
          theory: 'not_started' as TaskState,
          ncert: 'not_started' as TaskState,
          exemplar: 'not_started' as TaskState,
          pyq: 'not_started' as TaskState,
          cbq: 'not_started' as TaskState,
          revision: 'not_started' as TaskState,
          test: 'not_started' as TaskState,
        },
        notes: '',
        createdAt: now,
        updatedAt: now,
      };

      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          chapters: [...sub.chapters, newCh],
        };
      });

      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  // 3. Edit Chapter Name
  const handleEditChapter = (subjectId: string, chapterId: string, newName: string) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          chapters: sub.chapters.map((ch) =>
            ch.id === chapterId ? { ...ch, name: newName, updatedAt: now } : ch
          ),
        };
      });
      return { ...prof, subjects: updatedSubjects };
    });
  };

  // 4. Delete Chapter
  const handleDeleteChapter = (subjectId: string, chapterId: string) => {
    updateActiveProfile((prof) => {
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          chapters: sub.chapters.filter((ch) => ch.id !== chapterId),
        };
      });
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  // 5. Update Chapter Notes
  const handleUpdateChapterNotes = (subjectId: string, chapterId: string, notes: string) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        return {
          ...sub,
          chapters: sub.chapters.map((ch) =>
            ch.id === chapterId ? { ...ch, notes, updatedAt: now } : ch
          ),
        };
      });
      return { ...prof, subjects: updatedSubjects };
    });
  };

  // 6. Load Official CBSE 10th Syllabus
  const handleLoadOfficialSubjectChapters = (subjectId: string) => {
    const chapters = createOfficialChaptersForSubject(subjectId);
    updateActiveProfile((prof) => {
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        return { ...sub, chapters };
      });
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  const handleLoadAllOfficialSyllabus = () => {
    updateActiveProfile((prof) => {
      const updatedSubjects = prof.subjects.map((sub) => ({
        ...sub,
        chapters: createOfficialChaptersForSubject(sub.id),
      }));
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  // 7. Manual Quick Log Study Streak
  const handleQuickLogStreak = () => {
    updateActiveProfile((prof) => {
      return recordStudyActivity(prof, 1);
    }, true);
  };

  // 8. Study Tasks (To-Do)
  const handleAddTask = (taskData: Omit<StudyTask, 'id' | 'createdAt'>) => {
    updateActiveProfile((prof) => {
      const newTask: StudyTask = {
        ...taskData,
        id: `task-${Date.now().toString(36)}`,
        createdAt: new Date().toISOString(),
      };
      return {
        ...prof,
        studyTasks: [newTask, ...prof.studyTasks],
      };
    });
  };

  const handleToggleTask = (taskId: string) => {
    updateActiveProfile((prof) => {
      let markedComplete = false;
      const updatedTasks = prof.studyTasks.map((t) => {
        if (t.id !== taskId) return t;
        const nextCompleted = !t.completed;
        if (nextCompleted) markedComplete = true;
        return {
          ...t,
          completed: nextCompleted,
          completedAt: nextCompleted ? new Date().toISOString() : undefined,
        };
      });

      let updatedProf: Profile = { ...prof, studyTasks: updatedTasks };
      if (markedComplete) {
        updatedProf = recordStudyActivity(updatedProf, 1);
      }
      return updatedProf;
    }, true);
  };

  const handleDeleteTask = (taskId: string) => {
    updateActiveProfile((prof) => {
      return {
        ...prof,
        studyTasks: prof.studyTasks.filter((t) => t.id !== taskId),
      };
    });
  };

  // 9. Study Time Analytics & Session Logging (from Timer)
  const handleRecordStudySession = (sessionData: Omit<StudySession, 'id'>) => {
    updateActiveProfile((prof) => {
      const newSession: StudySession = {
        ...sessionData,
        id: `sess-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      };

      // Record study activity for streak
      let updatedProf: Profile = {
        ...prof,
        studySessions: [newSession, ...(prof.studySessions || [])],
      };
      updatedProf = recordStudyActivity(updatedProf, 1);
      return updatedProf;
    }, true);
  };

  // 10. Datesheet Management
  const handleUpdateDatesheetItem = (item: DatesheetItem) => {
    updateActiveProfile((prof) => {
      return {
        ...prof,
        datesheet: prof.datesheet.map((d) => (d.id === item.id ? item : d)),
      };
    });
  };

  const handleAddDatesheetItem = (item: DatesheetItem) => {
    updateActiveProfile((prof) => {
      return {
        ...prof,
        datesheet: [...prof.datesheet, item],
      };
    });
  };

  const handleDeleteDatesheetItem = (id: string) => {
    updateActiveProfile((prof) => {
      return {
        ...prof,
        datesheet: prof.datesheet.filter((d) => d.id !== id),
      };
    });
  };

  const handleResetDefaultDatesheet = () => {
    updateActiveProfile((prof) => {
      return {
        ...prof,
        datesheet: JSON.parse(JSON.stringify(DEFAULT_DATESHEET)),
      };
    });
  };

  // 11. Profile Operations
  const handleSelectProfile = (id: string) => {
    const nextState: AppState = { ...appState, activeProfileId: id };
    commitState(nextState);
  };

  const handleCreateProfile = (name: string, targetScore: number) => {
    const newProf = createDefaultProfile(name);
    newProf.targetScore = targetScore;
    const nextState: AppState = {
      ...appState,
      profiles: [...appState.profiles, newProf],
      activeProfileId: newProf.id,
    };
    commitState(nextState, true);
  };

  const handleUpdateProfile = (profileId: string, name: string, targetScore: number) => {
    const updatedProfiles = appState.profiles.map((p) =>
      p.id === profileId ? { ...p, name, targetScore } : p
    );
    const nextState: AppState = { ...appState, profiles: updatedProfiles };
    commitState(nextState);
  };

  const handleDeleteProfile = (profileId: string) => {
    if (appState.profiles.length <= 1) return;
    const remaining = appState.profiles.filter((p) => p.id !== profileId);
    const nextActive =
      appState.activeProfileId === profileId ? remaining[0].id : appState.activeProfileId;
    const nextState: AppState = {
      ...appState,
      profiles: remaining,
      activeProfileId: nextActive,
    };
    commitState(nextState, true);
  };

  // 12. Apply Imported State & Restore Snapshot
  const handleApplyImportedState = (importedState: AppState) => {
    commitState(importedState, true);
  };

  const handleRestoreSnapshot = (snapshot: BackupSnapshot) => {
    commitState(snapshot.state, false);
  };

  // 13. Reset All Data
  const handleResetAllData = () => {
    const fresh = createInitialAppState(currentUser?.id);
    commitState(fresh, true);
  };

  // 14. Admin Master Controls (Full Editing Authority & Data Isolation)
  const isAdmin = isUserAdmin(currentUser);

  const handleAdminOverrideStreak = (currentStreak: number, longestStreak: number) => {
    updateActiveProfile((prof) => ({
      ...prof,
      currentStreak,
      longestStreak: Math.max(longestStreak, currentStreak),
    }), true);
  };

  const handleAdminOverrideTarget = (targetScore: number) => {
    updateActiveProfile((prof) => ({
      ...prof,
      targetScore,
    }), true);
  };

  const handleAdminAddSubject = (name: string, color: string) => {
    updateActiveProfile((prof) => {
      const subjectId = name.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 20) + '-' + Date.now().toString(36);
      const newSubject: Subject = {
        id: subjectId,
        name,
        color,
        accent: color,
        icon: 'BookOpen',
        chapters: [],
      };
      return {
        ...prof,
        subjects: [...prof.subjects, newSubject],
      };
    }, true);
  };

  const handleAdminEditSubject = (subjectId: string, name: string, color: string) => {
    updateActiveProfile((prof) => {
      const updatedSubjects = prof.subjects.map((sub) =>
        sub.id === subjectId ? { ...sub, name, color } : sub
      );
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  const handleAdminDeleteSubject = (subjectId: string) => {
    updateActiveProfile((prof) => {
      const remaining = prof.subjects.filter((sub) => sub.id !== subjectId);
      return { ...prof, subjects: remaining };
    }, true);
    if (selectedSubjectId === subjectId) {
      const firstRem = activeProfile.subjects.find((s) => s.id !== subjectId);
      if (firstRem) setSelectedSubjectId(firstRem.id);
    }
  };

  const handleAdminBatchSetSubject = (subjectId: string, state: TaskState) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        const updatedChapters = sub.chapters.map((ch) => ({
          ...ch,
          tasks: {
            theory: state,
            ncert: state,
            exemplar: state,
            pyq: state,
            cbq: state,
            revision: state,
            test: state,
          },
          updatedAt: now,
        }));
        return { ...sub, chapters: updatedChapters };
      });
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  const handleAdminBatchSetChapterTasks = (subjectId: string, chapterId: string, state: TaskState) => {
    updateActiveProfile((prof) => {
      const now = new Date().toISOString();
      const updatedSubjects = prof.subjects.map((sub) => {
        if (sub.id !== subjectId) return sub;
        const updatedChapters = sub.chapters.map((ch) => {
          if (ch.id !== chapterId) return ch;
          return {
            ...ch,
            tasks: {
              theory: state,
              ncert: state,
              exemplar: state,
              pyq: state,
              cbq: state,
              revision: state,
              test: state,
            },
            updatedAt: now,
          };
        });
        return { ...sub, chapters: updatedChapters };
      });
      return { ...prof, subjects: updatedSubjects };
    }, true);
  };

  const pendingTasksCount = activeProfile.studyTasks.filter((t) => !t.completed).length;

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-blue-500 selection:text-white">
      {/* Offline Status Pill */}
      <OfflineIndicator />

      {/* Top Header with Brand Logo & Auth */}
      <Header
        theme={appState.theme}
        onToggleTheme={handleToggleTheme}
        profiles={appState.profiles}
        activeProfile={activeProfile}
        onSelectProfile={handleSelectProfile}
        onOpenNewProfileModal={() => {
          setNewProfileName('');
          setNewProfileTarget(95);
          setIsNewProfileModalOpen(true);
        }}
        onNavigateToSettings={() => setActiveTab('settings')}
        currentUser={currentUser}
        onOpenAuthModal={() => setAuthModalOpen(true)}
        isAdmin={isAdmin}
        onOpenAdminCenter={() => setAdminCenterOpen(true)}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 pt-5">
        {activeTab === 'dashboard' && (
          <DashboardView
            profile={activeProfile}
            onNavigateTab={setActiveTab}
            onSelectSubject={setSelectedSubjectId}
            onLoadOfficialSyllabus={handleLoadAllOfficialSyllabus}
            onQuickLogStreak={handleQuickLogStreak}
            onToggleTaskComplete={handleToggleTask}
            onOpenAddTaskModal={() => setActiveTab('tasks')}
          />
        )}

        {activeTab === 'chapters' && (
          <ChaptersView
            subjects={activeProfile.subjects}
            selectedSubjectId={selectedSubjectId}
            onSelectSubjectId={setSelectedSubjectId}
            onUpdateTaskState={handleUpdateTaskState}
            onAddChapter={handleAddChapter}
            onEditChapter={handleEditChapter}
            onDeleteChapter={handleDeleteChapter}
            onUpdateChapterNotes={handleUpdateChapterNotes}
            onLoadOfficialSubjectChapters={handleLoadOfficialSubjectChapters}
            isAdmin={isAdmin}
            onOpenAdminCenter={() => setAdminCenterOpen(true)}
            onBatchSetChapterTasks={handleAdminBatchSetChapterTasks}
          />
        )}

        {activeTab === 'focus' && (
          <FocusToolsView
            subjects={activeProfile.subjects}
            studySessions={activeProfile.studySessions || []}
            onRecordStudySession={handleRecordStudySession}
          />
        )}

        {activeTab === 'datesheet' && (
          <DatesheetView
            datesheet={activeProfile.datesheet}
            onUpdateDatesheetItem={handleUpdateDatesheetItem}
            onAddDatesheetItem={handleAddDatesheetItem}
            onDeleteDatesheetItem={handleDeleteDatesheetItem}
            onResetDefaultDatesheet={handleResetDefaultDatesheet}
          />
        )}

        {activeTab === 'streak' && (
          <StreakView
            profile={activeProfile}
            onQuickLogStreak={handleQuickLogStreak}
          />
        )}

        {activeTab === 'tasks' && (
          <NotesAndTodoView
            tasks={activeProfile.studyTasks}
            subjects={activeProfile.subjects}
            onAddTask={handleAddTask}
            onToggleTask={handleToggleTask}
            onDeleteTask={handleDeleteTask}
            onUpdateChapterNotes={handleUpdateChapterNotes}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            appState={appState}
            activeProfile={activeProfile}
            backups={backups}
            onSelectProfile={handleSelectProfile}
            onCreateProfile={handleCreateProfile}
            onUpdateProfile={handleUpdateProfile}
            onDeleteProfile={handleDeleteProfile}
            onApplyImportedState={handleApplyImportedState}
            onRestoreSnapshot={handleRestoreSnapshot}
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        pendingTasksCount={pendingTasksCount}
        streakCount={activeProfile.currentStreak}
      />

      {/* Supabase Email/Password Auth Modal */}
      <AuthModal
        currentUser={currentUser}
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
        onLogoutSuccess={handleLogoutSuccess}
      />

      {/* Header Quick Create Profile Modal */}
      {isNewProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Create New Student Profile
            </h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newProfileName.trim()) return;
                handleCreateProfile(newProfileName.trim(), Number(newProfileTarget) || 95);
                setIsNewProfileModalOpen(false);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Student Name
                </label>
                <input
                  type="text"
                  autoFocus
                  required
                  placeholder="e.g. Ansh - Class 10"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Target Score Percentage (%)
                </label>
                <input
                  type="number"
                  min={50}
                  max={100}
                  value={newProfileTarget}
                  onChange={(e) => setNewProfileTarget(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewProfileModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 text-white shadow-md shadow-blue-500/30"
                >
                  Create Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Master Control Center (Isolated Admin Session) */}
      <AdminControlCenter
        isOpen={adminCenterOpen}
        onClose={() => setAdminCenterOpen(false)}
        activeProfile={activeProfile}
        appState={appState}
        onOverrideStreak={handleAdminOverrideStreak}
        onUpdateProfileNameAndTarget={(name, targetScore) => {
          updateActiveProfile((prof) => ({ ...prof, name, targetScore }), true);
        }}
        onAddSubject={handleAdminAddSubject}
        onEditSubject={handleAdminEditSubject}
        onDeleteSubject={handleAdminDeleteSubject}
        onBatchSetSubjectChapters={handleAdminBatchSetSubject}
        onLoadOfficialSyllabus={handleLoadAllOfficialSyllabus}
      />
    </div>
  );
}
